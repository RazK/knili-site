/**
 * The orchestrator, as an MV3 service worker.
 *
 * It owns the run: compile the envelope, search the stores, decide, then drive
 * one tab to a filled cart and checkout. Content scripts come and go with every
 * navigation, so all state lives here and the panel re-renders from it whenever
 * it reappears.
 *
 * The purchase boundary is not enforced in this file. It is a declarative
 * network rule the browser applies itself (rules.json), which is why there is
 * nothing here that could be talked out of it.
 */
import { compile, research, decide, hardConstraints, checkoutConstraints, label } from './lib/pipeline.js';
import { detectPlatform, shopify, woocommerce, opencart, originOf } from './lib/platforms.js';
import { discoverShops } from './lib/discover.js';

const PLATFORM_BY_KEY = { shopify, woocommerce, opencart };

/** Stores to search when the user has not named their own. All real, all Shopify. */
// Empty on purpose. Shops come from the open web now; this list is only what
// the user has explicitly pinned, and pinning nothing is the normal case.
const DEFAULT_STORES = [];

/** The only personal data in the system. Never leaves the device. */
const DEFAULT_PROFILE = {
  first_name: '', last_name: '', email: '', telephone: '',
  address_1: '', address_2: '', city: '', postcode: '', country: '', zone: '',
};

const state = {
  runId: null, status: 'idle', events: [], brief: null,
  decision: null, attempts: [], result: null, tabId: null,
  cancelled: false,
  // Which panel the user is actually watching: 'inline' or 'side-panel'.
  surface: null,
};

/** Cooperative stop. Checked between phases and between merchants: a run that
 *  cannot be called off is a run you have to watch. */
class Stopped extends Error { constructor() { super('Stopped'); this.stopped = true; } }
const checkStopped = () => { if (state.cancelled) throw new Stopped(); };
const ports = new Set();

function emit(e) {
  const ev = { at: Date.now(), ...e };
  state.events.push(ev);
  for (const p of ports) { try { p.postMessage(ev); } catch { ports.delete(p); } }
}
const step = (level, text, extra = {}) => emit({ t: 'step', level, text, ...extra });
const setStatus = (s, extra = {}) => { state.status = s; emit({ t: 'state', state: s, ...extra }); };
const sleep = ms => new Promise(r => setTimeout(r, ms));

const getStores = async () => (await chrome.storage.local.get('stores')).stores || DEFAULT_STORES;

/**
 * Shops that have already told us, at their own checkout, that they will not
 * post to a country. Remembered between runs: discovering it costs a cart, a
 * checkout and fifteen seconds, and the answer does not change tomorrow.
 */
const getRefusals = async () => (await chrome.storage.local.get('refusals')).refusals || {};
async function rememberRefusal(origin, country) {
  if (!origin || !country) return;
  const all = await getRefusals();
  const list = new Set(all[country] || []);
  list.add(origin);
  all[country] = [...list].slice(-200);
  await chrome.storage.local.set({ refusals: all });
}
const getProfile = async () => ({ ...DEFAULT_PROFILE, ...((await chrome.storage.local.get('profile')).profile || {}) });

function snapshot() {
  return {
    runId: state.runId, status: state.status, events: state.events, brief: state.brief,
    decision: state.decision, attempts: state.attempts, result: state.result,
    blocked: state.blocked || 0,
    work: {
      compared: state.compared || 0, stores: state.storesSearched || 0,
      facts: state.facts || 0, fields: state.fields || 0,
      // A finished run took what it took; the clock stops when it ends.
      seconds: state.seconds ?? (state.startedAt ? Math.max(1, Math.round((Date.now() - state.startedAt) / 1000)) : 0),
    },
  };
}

// -------------------------------------------------------- opening the panel

/** Is the run being watched from Chrome's side panel rather than the page? */
async function sidePanelOpen() {
  try {
    const views = await chrome.runtime.getContexts({ contextTypes: ['SIDE_PANEL'] });
    return views.length > 0;
  } catch { return false; }
}

/** Injected on demand, so no page carries it uninvited. */
async function openPanel(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content/panel.js'] });
    return true;
  } catch (err) {
    console.warn('knili: cannot open panel here —', err.message);
    return false;
  }
}

chrome.action.onClicked.addListener(async tab => {
  if (!tab.id) return;
  state.tabId = tab.id;
  // Chrome's own side panel, so the page is resized by the browser instead of
  // being covered by us, and the panel survives the navigations a run performs.
  // Must be called in the gesture's own turn — no await before it.
  try {
    chrome.sidePanel.open({ tabId: tab.id });
    state.surface = 'side-panel';
    return;
  } catch (err) {
    console.warn('knili: side panel unavailable —', err.message);
  }
  const toggled = await chrome.tabs.sendMessage(tab.id, { t: 'toggle' }).catch(() => null);
  if (!toggled) await openPanel(tab.id);
});

// The side panel is a chrome-extension:// page, which is exactly what a
// browser-automation harness is not allowed to read. This opens the same panel
// inside the page instead, where it can be inspected and driven — and it is the
// panel any browser without a side panel gets anyway.
chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command !== 'open_inline' || !tab?.id) return;
  openInline(tab.id);
});

async function openInline(tabId) {
  state.tabId = tabId;
  state.surface = 'inline';
  // The worker can be torn down between the last navigation of a run and the
  // page finishing loading, and it comes back with an empty state — which is
  // how the panel disappeared at the checkout even after the surface fix.
  // Session storage outlives the worker and dies with the browser, which is
  // exactly the lifetime this fact has.
  chrome.storage.session?.set({ surface: 'inline', surfaceTab: tabId }).catch(() => {});
  const toggled = await chrome.tabs.sendMessage(tabId, { t: 'toggle' }).catch(() => null);
  if (!toggled) await openPanel(tabId);
}

// Keyboard shortcuts are a minefield on a Mac — Cmd+Shift+J is Chrome's own
// downloads window, Cmd+Shift+Y is a system service — and neither a toolbar
// click nor an accelerator can be performed by automation. A URL fragment can:
// land on any page with #knili-open and the panel opens itself. It costs one
// exact string comparison and it is how this thing gets tested without a human
// pressing keys.
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status !== 'complete') return;
  const url = tab?.url || '';
  if (/#knili-open$/.test(url)) return void openInline(tabId);
  // Reloading an unpacked extension otherwise means a human clicking a button
  // on chrome://extensions, which no automation can reach — so every code
  // change would cost a round trip through Raz. This costs one comparison.
  if (/#knili-reload$/.test(url)) chrome.runtime.reload();
});

/**
 * The run navigates its own tab; the panel has to come back with it.
 *
 * This used to skip re-injection whenever a side panel existed anywhere in the
 * browser — so opening the side panel once, in any window, silently killed the
 * in-page panel for every run afterwards. What matters is which surface this
 * run is being watched from, not whether the other one happens to be open.
 */
chrome.tabs.onUpdated.addListener(async (tabId, info) => {
  if (info.status !== 'complete') return;
  if (state.surface === null) {
    const saved = await chrome.storage.session?.get(['surface', 'surfaceTab']).catch(() => ({})) ?? {};
    if (saved.surface) { state.surface = saved.surface; state.tabId = state.tabId ?? saved.surfaceTab; }
  }
  if (tabId !== state.tabId) return;
  if (state.surface !== 'inline') return;
  // Not "while running" — the last navigation of an errand lands on the
  // checkout AFTER the run is finished, so an is-it-running test loses the
  // panel at the exact moment it has something to say. Any run in memory is
  // reason enough; the panel asks for the whole state when it reappears.
  if (!state.runId) {
    const { lastRun } = await chrome.storage.session?.get('lastRun').catch(() => ({})) ?? {};
    if (!lastRun) return;
  }
  await openPanel(tabId);
});

chrome.runtime.onConnect.addListener(port => {
  if (port.name !== 'knili') return;
  ports.add(port);
  // The panel does not know which tab it is in; the port does.
  const portTabId = port.sender?.tab?.id ?? null;
  if (portTabId && state.status === 'idle') state.tabId = portTabId;
  Promise.all([getStores(), getProfile()]).then(([stores, profile]) =>
    port.postMessage({ t: 'hello', state: snapshot(), stores, profile }));
  port.onDisconnect.addListener(() => ports.delete(port));
  port.onMessage.addListener(async msg => {
    if (msg.t === 'start') startRun(msg.text, portTabId);
    if (msg.t === 'cancel') {
      if (state.status !== 'idle' && state.status !== 'done') {
        state.cancelled = true;
        step('warn', 'Stopping — finishing the step in flight, then standing down.');
      }
    }
    if (msg.t === 'saveProfile') { await chrome.storage.local.set({ profile: msg.profile }); emit({ t: 'saved', what: 'details' }); }
    if (msg.t === 'saveStores') { await chrome.storage.local.set({ stores: msg.stores }); emit({ t: 'saved', what: 'stores' }); }
    if (msg.t === 'reset') {
      Object.assign(state, { runId: null, status: 'idle', events: [], brief: null, decision: null, attempts: [], result: null });
      emit({ t: 'reset' });
    }
  });
});

if (chrome.declarativeNetRequest.onRuleMatchedDebug) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(info => {
    step('stop', `The browser blocked an order submission: ${new URL(info.request.url).pathname.slice(0, 60)}`);
    state.blocked = (state.blocked || 0) + 1;
  });
}

// A read-only window into the run, so a test harness can see what the worker
// saw without reaching through a page that may have navigated away.
globalThis.__kniliSnapshot = () => snapshot();
globalThis.__kniliReset = () => {
  Object.assign(state, { runId: null, status: 'idle', events: [], brief: null,
    decision: null, attempts: [], result: null, blocked: 0, compared: 0, facts: 0, fields: 0, startedAt: null, seconds: null });
  emit({ t: 'reset' });
};

// ------------------------------------------------------------------- the run

async function startRun(text, fromTabId) {
  // A run that arrives while another is in flight used to return silently, which
  // looks identical to a dead worker from the panel: the button says "Working…"
  // forever and nothing ever explains why. Say so instead.
  if (state.status !== 'idle' && state.status !== 'done') {
    step('warn', `Already working on the previous errand (${state.status}). Reset it to start another.`);
    return;
  }
  Object.assign(state, {
    runId: 'r' + Date.now().toString(36), events: [], brief: null, decision: null,
    attempts: [], result: null, blocked: 0, startedAt: Date.now(), seconds: null, compared: 0, facts: 0, fields: 0,
    tabId: fromTabId ?? state.tabId,
    cancelled: false,
  });
  emit({ t: 'started', runId: state.runId, request: text });
  chrome.storage.session?.set({ lastRun: state.runId }).catch(() => {});

  const profile = await getProfile();

  try {
    setStatus('intake');
    const brief = compile(text);
    state.brief = { ...brief, constraints: brief.constraints.map(c => ({ ...c, label: c.kind === 'hard' ? label(c) : null })) };
    emit({ t: 'brief', brief: state.brief });
    step('done', `Envelope: ${hardConstraints(brief).map(label).join(' · ')}`);

    if (brief.unresolved.length) {
      const question = brief.unresolved.map(u => u.question).join(' ');
      setStatus('awaiting_user', { question });
      state.result = { state: 'awaiting_user', question };
      return finish();
    }

    // Who sells this? Ask the web, not a list. A list the user maintains by
    // hand is a whitelist, and it answers "65w charger" with four clothing
    // shops. Anything the user has pinned still counts, and so does the shop
    // they are standing on, but neither is the boundary of the search.
    checkStopped();
    setStatus('research');
    step('run', `Searching the web for shops that sell "${brief.query}"`);
    const wantsCountry = checkoutConstraints(brief).find(c => c.attr === 'shipsTo')?.value ?? null;
    const found = await discoverShops(brief.query, {
      country: wantsCountry, limit: 16,
      onStep: e => step(e.level, e.text),
    });
    step(found.length ? 'done' : 'warn',
      found.length ? `Found ${found.length} shops to look at` : 'The web search returned nothing');

    const refusedBefore = new Set(wantsCountry ? (await getRefusals())[wantsCountry] || [] : []);
    const stores = [];
    const seen = new Set();
    let skipped = 0;
    const add = s => {
      const o = originOf(s.origin);
      if (!o || seen.has(o)) return;
      seen.add(o);
      if (refusedBefore.has(o)) { skipped++; return; }
      stores.push({ ...s, origin: o });
    };
    const here = await currentStore(state.tabId);
    if (here) { add(here); step('done', `Including the store you are on: ${here.name}`); }
    (await getStores()).forEach(add);
    found.forEach(add);
    if (skipped) {
      step('done', `Skipped ${skipped} shop${skipped === 1 ? '' : 's'} that already refused ${wantsCountry}`);
    }
    state.storesSearched = stores.length;
    const candidates = await research({
      stores, query: brief.query,
      onStep: e => step(e.level, e.text, { url: e.url }),
      shouldStop: () => state.cancelled,
    });
    checkStopped();

    // "Nothing meets your constraints" is the wrong sentence when the truth is
    // that every shop found runs on a platform this cannot drive. In Israel
    // that is most of them, and the user deserves the real reason.
    if (!candidates.length && candidates.readable === 0 && candidates.unreadable > 0) {
      const message = `Found ${candidates.unreadable} shops selling this and could not drive any of them — ` +
        `they run on platforms I do not support yet.`;
      step('warn', message);
      setStatus('no_result');
      state.result = { state: 'no_result', message, query: brief.query, undrivable: candidates.unreadable };
      return finish();
    }
    state.compared = candidates.length;
    // Every attribute read off a listing, with a source and a timestamp. It is
    // the work nobody sees, so it is worth counting.
    state.facts = candidates.reduce((n, c) => n + Object.keys(c.evidence).length, 0);

    checkStopped();
    setStatus('decide');
    const decision = decide(candidates, brief);
    state.decision = uiDecision(decision);
    emit({ t: 'decision', ...state.decision });

    if (!decision.chosen) {
      const ceiling = hardConstraints(brief).find(c => c.attr === 'price')?.value;
      const message = decision.cheapestNear
        ? `Nothing under $${ceiling}. The closest that meets everything else is $${decision.cheapestNear.toFixed(2)}.`
        : `Nothing in these stores matches “${brief.query}” within your constraints.`;
      step('warn', message);
      setStatus('no_result');
      state.result = {
        state: 'no_result', message,
        ceiling,
        cheapest: decision.cheapestNear ?? null,
        query: brief.query,
      };
      return finish();
    }
    step('done', `Chose ${decision.chosen.title} — ${decision.rationale}`);

    checkStopped();
    setStatus('transact');
    await transact(decision, brief, profile);
  } catch (err) {
    if (err?.stopped) {
      step('done', 'Stopped. Nothing was bought, and nothing is waiting on you.');
      setStatus('stopped');
      state.result = { state: 'stopped', message: 'You stopped this run.' };
      return finish();
    }
    step('warn', `Run failed: ${err.message}`);
    setStatus('failed');
    state.result = { state: 'failed', error: err.message };
    finish();
  }
}

async function currentStore(tabId) {
  if (!tabId) return null;
  try {
    const tab = await chrome.tabs.get(tabId);
    const origin = originOf(tab.url);
    if (!origin || /^(chrome|about|edge|devtools)/.test(tab.url)) return null;
    if (!(await detectPlatform(origin))) return null;
    return { name: new URL(origin).hostname.replace(/^www\./, ''), origin };
  } catch { return null; }
}

const uiChosen = c => ({
  title: c.title, merchant: c.merchant, url: c.url, platform: c.platform, image: c.image ?? null,
  variant: c.variant ? { id: c.variant.id, title: c.variant.title, price: c.variant.price } : null,
  evidence: Object.values(c.evidence).map(e => ({ ...e })),
});

function uiDecision(d) {
  const cand = uiChosen;
  return {
    chosen: d.chosen ? cand(d.chosen) : null,
    rationale: d.rationale,
    rejected: d.rejected.slice(0, 8).map(r => ({
      title: r.candidate.title, merchant: r.candidate.merchant, url: r.candidate.url,
      price: r.candidate.evidence.price?.value ?? null,
      whyNot: r.failed.map(f => f.reason),
    })),
    alternates: d.ranked.slice(1, 4).map(cand),
  };
}

function finish() {
  state.status = 'done';
  state.seconds = Math.max(1, Math.round((Date.now() - (state.startedAt || Date.now())) / 1000));
  emit({
    t: 'end', result: state.result, attempts: state.attempts, blocked: state.blocked || 0,
    work: {
      compared: state.compared || 0, stores: state.storesSearched || 0,
      facts: state.facts || 0, fields: state.fields || 0,
      seconds: state.seconds,
    },
  });
}

// -------------------------------------------------------------- the transact

/**
 * `world` matters. Anything that reads or clicks the page runs in MAIN, where
 * the store's own scripts live. Anything that talks to the store's cart API
 * runs ISOLATED: themes routinely wrap window.fetch to fire their own cart
 * events, and a wrapped fetch is not one to hand a purchase decision to.
 */
async function exec(tabId, func, args = [], { world = 'MAIN', retry = 1 } = {}) {
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId }, func, args, world });
    // A frame that is being replaced answers with nothing at all. Same story as
    // the throw below: a moment, not a verdict.
    if (res?.result === undefined && retry > 0) {
      await sleep(700);
      return exec(tabId, func, args, { world, retry: retry - 1 });
    }
    return res?.result;
  } catch (err) {
    // A tab caught between two documents answers nothing. That is a moment,
    // not a verdict - ask again before reporting it as one.
    if (retry > 0) { await sleep(700); return exec(tabId, func, args, { world, retry: retry - 1 }); }
    // A tab that navigated away, or an error page, is a condition to report -
    // not a reason to abandon a cart that is already loaded.
    return { __unreachable: true, detail: err.message.slice(0, 90) };
  }
}

/**
 * Follow a store's /checkout and report the host it ends on, when that host is
 * not the store's own. Costs one request and saves a dead-end navigation.
 */
async function checkoutLivesElsewhere(checkoutUrl) {
  const own = new URL(checkoutUrl).origin;
  try {
    const res = await fetch(checkoutUrl, { credentials: 'include', redirect: 'follow' });
    const landed = new URL(res.url);
    return landed.origin === own ? null : landed.host;
  } catch {
    // Following it failed. That is itself the answer: if the checkout cannot be
    // reached from here, sending the tab there only produces an error page.
    try {
      const r = await fetch(checkoutUrl, { credentials: 'include', redirect: 'manual' });
      if (r.type === 'opaqueredirect' || (r.status >= 300 && r.status < 400)) return 'its own payment domain';
      return null;                       // it answered in place; the tab can go
    } catch {
      return 'a domain this browser cannot reach';
    }
  }
}

/**
 * True when the tab is sitting on a page the browser could not load. A tab
 * mid-navigation has no url yet, which is not the same thing - so look twice
 * before writing off a checkout that is merely slow.
 */
async function tabErrored(tabId) {
  for (let i = 0; i < 2; i++) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (/^(chrome|edge)-error/.test(tab.url || '')) return true;
      if (tab.url) return false;
    } catch { return true; }
    await new Promise(r => setTimeout(r, 900));
  }
  return false;
}

/**
 * A page is usable long before its last tracking beacon resolves, and some of
 * them never do. Waiting for `complete` means waiting on all of them; waiting
 * for the document to be parsed is what a person actually waits for.
 *
 * `expect` guards against answering with the page we are navigating away from,
 * which is already parsed and would resolve this instantly.
 */
function waitLoad(tabId, { expect = null, timeout = 30000 } = {}) {
  const same = u => String(u ?? '').split('#')[0].replace(/\/$/, '');
  const started = Date.now();
  return new Promise(resolve => {
    let settled = false;
    // Re-opening the page the tab is already on reloads it, but for a moment
    // the tab still reports the old document as complete. Answering then hands
    // back a frame that is about to be replaced, and whatever runs in it is
    // lost. So wait for the navigation to actually begin.
    let navigating = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      clearInterval(iv);
      chrome.tabs.onUpdated.removeListener(onUpdate);
      resolve();
    };
    const onUpdate = (id, info) => {
      if (id !== tabId) return;
      if (info.status === 'loading') navigating = true;
      if (info.status === 'complete' && navigating) finish();
    };
    chrome.tabs.onUpdated.addListener(onUpdate);

    const iv = setInterval(async () => {
      if (Date.now() - started > timeout) return finish();
      let tab;
      try { tab = await chrome.tabs.get(tabId); } catch { return finish(); }
      if (tab.status === 'loading') navigating = true;
      if (expect && same(tab.url) !== same(expect)) return;         // still the old page
      if (!navigating && Date.now() - started < 2500) return;       // it has not started yet
      if (tab.status === 'complete') return finish();
      try {
        const [r] = await chrome.scripting.executeScript({
          target: { tabId }, func: () => document.readyState,
        });
        if (r?.result === 'interactive' || r?.result === 'complete') finish();
      } catch { /* mid-navigation; ask again next tick */ }
    }, 250);
  });
}

/** The tab is often already where we want it, and a page load is not free. */
async function ensureOn(tabId, url, text) {
  const same = u => String(u ?? '').split('#')[0].replace(/\/$/, '');
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (tab && same(tab.url) === same(url)) return;
  await navigate(tabId, url, text);
}

async function openTab(url) {
  if (state.tabId) {
    try {
      await chrome.tabs.update(state.tabId, { url, active: true });
      await waitLoad(state.tabId, { expect: url });
      return state.tabId;
    } catch { /* the tab went away; make a new one */ }
  }
  const tab = await chrome.tabs.create({ url, active: true });
  state.tabId = tab.id;
  await waitLoad(tab.id, { expect: url });
  return tab.id;
}

async function navigate(tabId, url, text) {
  step('run', text || `Opening ${new URL(url).hostname}`, { url });
  await chrome.tabs.update(tabId, { url });
  await waitLoad(tabId, { expect: url });
  await sleep(600);
}

async function transact(decision, brief, profile) {
  const wantCountry = checkoutConstraints(brief).find(c => c.attr === 'shipsTo')?.value ?? null;
  const ceiling = hardConstraints(brief).find(c => c.attr === 'price')?.value ?? null;

  const unreachableCheckouts = new Set();

  // Merchants that have already told us, at their own checkout, that they will
  // not ship where this is going.
  const refuses = new Set();

  for (const [i, candidate] of decision.ranked.entries()) {
    // Between merchants is the honest place to stop: nothing half-added.
    checkStopped();

    if (refuses.has(originOf(candidate.url))) {
      record(candidate, 'no-shipping', `${candidate.merchant} already said it does not ship there`);
      continue;
    }
    const remaining = decision.ranked.length - i - 1;
    const origin = candidate.origin;
    // Every listing in a shop ends at the same checkout. One that could not be
    // opened has answered for all of them.
    if (unreachableCheckouts.has(origin)) continue;
    const platform = PLATFORM_BY_KEY[candidate.platform] ?? opencart;
    step('run', `Attempt ${i + 1}: ${candidate.title} at ${candidate.merchant}`);
    if (i > 0) {
      // The panel must never keep advertising a listing the run has walked away
      // from. Whatever it is working on now is the pick.
      const price = candidate.evidence.price?.value;
      state.decision = {
        ...state.decision,
        chosen: uiChosen(candidate),
        rationale: `$${price?.toFixed(2)} at ${candidate.merchant}. Everything ranked above it could not be bought.`,
      };
      emit({ t: 'decision', ...state.decision });
    }

    // Start from an empty basket, so an abandoned attempt cannot ride along.
    const tabId = await openTab(platform.cartPage(origin));
    const CLEAR = { shopify: PAGE.shopifyClear, woocommerce: PAGE.wooClear, opencart: PAGE.opencartClear };
    const emptyBasket = () => exec(tabId, CLEAR[candidate.platform] ?? PAGE.opencartClear, [], { world: 'ISOLATED' });
    await emptyBasket();

    // --- into the cart ---
    if (candidate.platform === 'shopify' && candidate.variant) {
      // Shopify's cart permalink is a redirect, and on stores with Shop Pay it
      // lands on a hosted checkout on another domain before the cart has been
      // seen at all. Adding through the store's own cart API keeps it here.
      const v = candidate.variant;
      const suffix = v.title && v.title !== 'Default Title' ? ` (${v.title})` : '';
      step('run', `Adding ${candidate.title}${suffix}`);
      const added = await exec(tabId, PAGE.shopifyAdd, [v.id], { world: 'ISOLATED' });
      if (!added?.ok) {
        record(candidate, 'cart-failed', added?.detail || 'the store refused the add');
        if (remaining) { step('warn', `Could not cart it — ${added?.detail}`); continue; }
        return end('blocked', { reason: added?.detail || 'could not cart anything' });
      }
      await navigate(tabId, platform.cartPage(origin), 'Opening the cart');
    } else {
      await navigate(tabId, candidate.url, `Opening ${candidate.title}`);
      step('run', `Adding ${candidate.title}`);
      // Post the id where the store gives us one; fall back to the button.
      const added = candidate.platform === 'woocommerce'
        ? await exec(tabId, PAGE.wooAdd, [], { world: 'ISOLATED' })
        : candidate.productId
          ? await exec(tabId, PAGE.opencartAdd, [candidate.productId], { world: 'ISOLATED' })
          : await exec(tabId, PAGE.addToCart);
      if (!added?.ok) {
        record(candidate, 'cart-failed', added?.detail || 'no add-to-cart control');
        if (remaining) { step('warn', 'Could not cart it — trying the next listing'); continue; }
        return end('blocked', { reason: added?.detail || 'could not cart anything' });
      }
      await navigate(tabId, platform.cartPage(origin), 'Opening the cart');
    }

    // A cart read a moment too early reads empty, and an empty cart is a
    // reason to abandon a listing - so ask more than once before believing it.
    const READ = { shopify: PAGE.shopifyCart, woocommerce: PAGE.wooCart };
    const readCart = () => READ[candidate.platform]
      ? exec(tabId, READ[candidate.platform], [], { world: 'ISOLATED' })
      : exec(tabId, PAGE.readCart);
    let cart = await readCart();
    for (let n = 0; n < 3 && !cart?.lines?.length; n++) { await sleep(900); cart = await readCart(); }
    emit({ t: 'cart', cart });
    if (!cart?.lines?.length) {
      record(candidate, 'cart-empty', 'the store did not accept the item');
      if (remaining) { step('warn', 'Cart came back empty — trying the next listing'); await emptyBasket(); continue; }
      return end('blocked', { reason: 'nothing stayed in a cart' });
    }
    step('done', `In the cart: ${cart.lines.map(l => l.name.slice(0, 40)).join(', ')}`);

    if (cart.blocked) {
      record(candidate, 'not-purchasable', cart.notice || 'the store blocks checkout for this line');
      // Put it back before walking away: the tab is sitting on a settled cart
      // page right now, which is the one moment emptying it is reliable.
      if (remaining) { step('warn', 'This store will not check it out — next listing'); await emptyBasket(); continue; }
      return end('blocked', { reason: cart.notice || 'no line could be checked out' });
    }

    // --- to the checkout ---
    const checkoutUrl = platform.checkoutPage(origin);

    // Where does this store's checkout actually live? Many hand off to a
    // wallet on another domain. Finding that out before navigating is the
    // difference between a loaded cart and the user staring at an error page.
    // A cart is not the errand. If this shop's checkout cannot be opened, the
    // only place that can answer "does it ship to Israel" is out of reach, so
    // keep going while there is anywhere else to go - and do not try the rest
    // of this shop's listings, because they end at the same checkout.
    const unreachable = async why => {
      unreachableCheckouts.add(origin);
      record(candidate, 'cart-ready', cart.totalText || `${candidate.title} in the cart`);
      if (decision.ranked.slice(i + 1).some(c => !unreachableCheckouts.has(c.origin))) {
        step('warn', `${candidate.merchant}: ${why} — looking for a shop that can finish`);
        await emptyBasket();
        return null;
      }
      step('warn', `${candidate.merchant}: ${why} — the cart is loaded and waiting`);
      await ensureOn(tabId, platform.cartPage(origin), 'Back to the cart');
      return end('cart_ready', {
        candidate: candidate.title, merchant: candidate.merchant,
        itemPrice: candidate.evidence.price?.value ?? null,
        total: cart.total ?? null, totalText: cart.totalText ?? null,
        url: checkoutUrl, productUrl: candidate.url, cartUrl: platform.cartPage(origin),
      });
    };

    const elsewhere = await checkoutLivesElsewhere(checkoutUrl);
    if (elsewhere) {
      const done = await unreachable(`its checkout answers from ${elsewhere}`);
      if (done) return done;
      continue;
    }

    await navigate(tabId, checkoutUrl, 'Going to the checkout');
    // A checkout is ready when its fields are there, not when its document is.
    // Deciding otherwise on the first tick is how a perfectly good checkout
    // gets reported as having no address fields on it.
    for (let n = 0; n < 24; n++) {
      const ready = await exec(tabId, PAGE.checkoutReady);
      if (ready?.ready) break;
      await sleep(700);
    }
    if (await tabErrored(tabId)) {
      const done = await unreachable('its checkout would not load from here');
      if (done) return done;
      continue;
    }
    const gate = await exec(tabId, PAGE.checkoutGate);
    if (gate?.bouncedToCart) {
      record(candidate, 'checkout-refused', 'the store sent us back to the cart');
      if (remaining) { step('warn', `${candidate.merchant} refuses checkout here — next listing`); continue; }
      return end('blocked', { reason: 'every store refused checkout' });
    }
    if (gate?.hasGuest) { step('run', 'Choosing guest checkout'); await exec(tabId, PAGE.chooseGuest); await sleep(2200); }

    // --- the constraint only a checkout can answer ---
    if (wantCountry) {
      const ships = await exec(tabId, PAGE.countryOffered, [wantCountry]);
      emit({ t: 'shipcheck', country: wantCountry, ...ships });
      if (ships && ships.count > 0 && !ships.offered) {
        record(candidate, 'no-shipping', `does not offer ${wantCountry}`);
        step('warn', `${candidate.merchant} does not ship to ${wantCountry}`);
        // Shipping is a property of the SHOP, not of the item. Trying the next
        // charger at a merchant that has just said it will not post to Israel
        // is a cart, a checkout and fifteen seconds spent to be told the same
        // thing again — which is exactly what it did before this line.
        refuses.add(originOf(candidate.url));
        rememberRefusal(originOf(candidate.url), wantCountry);
        if (remaining) continue;
        return end('blocked', { reason: `nothing here ships to ${wantCountry}`, ...blockedBecause(), wanted: wantCountry });
      }
      if (ships?.offered) step('done', `${candidate.merchant} lists ${wantCountry} among ${ships.count} destinations`);
    }

    // --- fill what the browser would autofill ---
    const hasDetails = profile.address_1 && profile.city;
    if (hasDetails) {
      step('run', 'Filling the checkout');
      const filled = await exec(tabId, PAGE.fillCheckout, [profile]);
      state.fields = filled?.filled?.length ?? 0;
      step(filled?.filled?.length ? 'done' : 'warn',
        filled?.filled?.length ? `Filled ${filled.filled.length} fields: ${filled.filled.join(', ')}`
          : 'No address fields matched on this page');
      // A region list that never refreshed after the country changed is the
      // previous country's list, and reporting it says something untrue.
      if (filled?.zone && filled?.zones?.length) {
        step('done', `${profile.country} regions offered: ${filled.zones.slice(0, 6).join(', ')}${filled.zones.length > 6 ? '…' : ''} → ${filled.zone}`);
      }

      for (let s = 0; s < 5; s++) {
        const adv = await exec(tabId, PAGE.advance);
        if (adv?.refused) step('stop', `Refused to click “${adv.refused}” — that control commits the purchase`);
        if (!adv?.moved) break;
        step('run', `Checkout step: ${adv.clicked}`);
        await sleep(2600);
        // Only re-fill when the new step actually asks for something. Running
        // the filler again re-selects the country, which reloads the region
        // list and undoes the step that was just completed.
        if (await exec(tabId, PAGE.needsFill)) await exec(tabId, PAGE.fillCheckout, [profile]);
      }
    } else {
      step('warn', 'No delivery details saved — add them in the panel and it will fill the checkout too');
    }

    await exec(tabId, PAGE.revealFilled);
    await sleep(600);
    let readiness = await exec(tabId, PAGE.readiness, [candidate.title]);
    if (readiness?.__unreachable) {
      // The checkout moved somewhere this browser cannot follow. Report the
      // cart, which is real, rather than an object about a dead frame.
      readiness = { ready: false, missing: ['the checkout moved to the store’s own payment domain'],
        totalText: cart.totalText ?? null, total: cart.total ?? null, url: checkoutUrl };
    }
    emit({ t: 'readiness', readiness });

    const price = candidate.evidence.price?.value ?? null;

    // The till is the only place the real number appears. A $4 notebook with
    // $33 of shipping is a $37 purchase, and a ceiling that only ever looks at
    // the listing is not a ceiling — it is a hope.
    const atTill = readiness?.total ?? null;
    // Only compare like with like. A pound total against a dollar ceiling is
    // not a comparison, and pretending otherwise is how you get told a £71.50
    // checkout is within a $25 budget.
    const tillCurrency = (readiness?.currency || '$').toUpperCase().replace('USD', '$');
    const comparable = tillCurrency === '$';
    if (!comparable && atTill != null) {
      step('warn', `${candidate.merchant} bills in ${readiness.currency} — ${readiness.totalText} at the till, which your $${ceiling ?? '—'} budget cannot be compared against.`);
    }
    if (comparable && ceiling != null && atTill != null && atTill > ceiling) {
      record(candidate, 'over-ceiling', `${money(atTill)} at the till against your ${money(ceiling)}`);
      step('warn', `${candidate.merchant}: ${money(atTill)} at the till — over your ${money(ceiling)} once shipping is counted`);
      if (remaining) continue;
      return end('needs_approval', {
        readiness, candidate: candidate.title, merchant: candidate.merchant,
        itemPrice: price, total: atTill, totalText: readiness?.totalText,
        image: candidate.image ?? null, shipsTo: wantCountry ?? null,
        url: readiness?.url, productUrl: candidate.url,
        message: `${money(atTill)} at the till, once ${money(atTill - (price ?? 0))} of shipping is added — over your ${money(ceiling)}.`,
        ...blockedBecause(),
      });
    }

    if (ceiling != null && price != null && price > ceiling) {
      record(candidate, 'over-budget', `$${price} against a $${ceiling} ceiling`);
      if (remaining) continue;
      return end('needs_approval', { readiness, candidate: candidate.title, merchant: candidate.merchant });
    }

    const wall = await exec(tabId, PAGE.verificationWall, []);
    if (wall?.wall) {
      step('warn', `${wall.where} wants a code to confirm it is you — that one is yours to answer.`);
    }

    const optOut = await exec(tabId, PAGE.clearMarketing, []);
    if (optOut?.cleared) {
      step('done', `Unticked ${optOut.cleared} marketing opt-in${optOut.cleared === 1 ? '' : 's'} the shop had pre-ticked`);
    }

    // Never hand someone a payment form without what they are paying for.
    const summary = await exec(tabId, PAGE.revealOrderSummary, []);
    if (summary?.opened) step('done', 'Opened the order summary so you can see what is in it');

    const done = readiness?.ready && hasDetails;
    record(candidate, done ? 'ready' : 'cart-ready', readiness?.totalText || `${candidate.title} in the cart`);
    step('done', done
      ? 'Checkout filled and waiting for you.'
      : 'Cart loaded and the checkout is open — the last details are yours.');

    return end(done ? 'ready' : 'cart_ready', {
      readiness, url: readiness?.url, candidate: candidate.title, merchant: candidate.merchant,
      itemPrice: price, total: readiness?.total, totalText: readiness?.totalText,
      productUrl: candidate.url, image: candidate.image ?? null,
      shipsTo: wantCountry ?? null, verify: wall?.wall ? wall.where : null,
    });
  }
  return end('blocked', { reason: 'candidates exhausted', ...blockedBecause(), wanted: wantCountry ?? null });
}

function record(candidate, outcome, detail) {
  state.attempts.push({ merchant: candidate.merchant, candidate: candidate.title, outcome, detail });
  emit({ t: 'attempts', attempts: state.attempts });
}

/**
 * "No store produced a working cart" is true and useless. Five shops stocked
 * the coffee and none of them post to Israel — that is a different sentence,
 * and it is the one that tells you what to change.
 */
function blockedBecause() {
  const tally = {};
  const shops = {};
  for (const a of state.attempts) {
    tally[a.outcome] = (tally[a.outcome] || 0) + 1;
    (shops[a.outcome] = shops[a.outcome] || new Set()).add(a.merchant);
  }
  const top = Object.entries(tally).sort((a, b) => b[1] - a[1])[0];
  return {
    tally,
    dominant: top ? top[0] : null,
    dominantShops: top ? shops[top[0]].size : 0,
  };
}

function end(status, extra) {
  setStatus(status, extra);
  state.result = { state: status, ...extra };
  finish();
  return state.result;
}

// --------------------------------------------------------- injected page code
//
// Everything below runs inside the merchant's page. Each function is
// self-contained: chrome.scripting serialises it, so it closes over nothing.

const PAGE = {
  /**
   * Shopify collapses the order summary on narrow viewports, and the panel
   * makes every viewport narrow. Landing someone on a payment form with the
   * thing they are buying hidden behind a disclosure is the one place this
   * product cannot afford to be coy, so open it and leave it open.
   */
  revealOrderSummary: function () {
    const opener = [...document.querySelectorAll('button,summary,[role="button"]')].find(el => {
      const t = `${el.textContent || ''} ${el.getAttribute('aria-label') || ''}`.toLowerCase();
      return /order summary|show summary|order details/.test(t)
        && el.getAttribute('aria-expanded') !== 'true';
    });
    if (!opener) return { opened: false, alreadyOpen: !!document.querySelector('[data-order-summary],.order-summary') };
    opener.click();
    return { opened: true };
  },

  /**
   * WooCommerce's Store API is the same bargain Shopify offers: a cart the
   * shop itself owns, addressed by id rather than by clicking a theme's
   * buttons. It wants a nonce, which the cart itself hands out, and for a
   * product sold in sizes it wants the size named.
   */
  shopifyClear: async function () {
    // Clicking remove controls one at a time, each with a page reload, races
    // the reload and leaves lines behind. The store's own endpoint does not.
    try {
      const res = await fetch('/cart/clear.js', { method: 'POST', credentials: 'same-origin' });
      const j = await res.json();
      return { empty: (j.items || []).length === 0, removed: 1 };
    } catch (err) {
      return { empty: false, detail: err.message.slice(0, 80) };
    }
  },

  shopifyAdd: async function (variantId) {
    const post = () => fetch('/cart/add.js', {
      method: 'POST', credentials: 'same-origin',
      headers: { 'content-type': 'application/json', accept: 'application/json' },
      body: JSON.stringify({ items: [{ id: Number(variantId), quantity: 1 }] }),
    });
    try {
      let res = await post();
      // 429 is a store asking to be asked again, not a store saying no. Giving
      // up on it abandons a listing that was perfectly purchasable - but so
      // does waiting on it long enough that the person gives up instead, so
      // take the store's own Retry-After and cap the whole thing at a few
      // seconds before moving to the next listing.
      for (let n = 0; n < 3 && res.status === 429; n++) {
        const asked = Number(res.headers.get('retry-after')) * 1000;
        await new Promise(r => setTimeout(r, Math.min(asked || 700 * (n + 1), 2000)));
        res = await post();
      }
      if (!res.ok) return { ok: false, detail: `the store returned ${res.status}` };
      const j = await res.json();
      return { ok: true, added: j.items?.[0]?.title || j.title || 'item' };
    } catch (err) {
      return { ok: false, detail: err.message.slice(0, 80) };
    }
  },

  /**
   * WooCommerce's Store API is the same bargain Shopify offers: a cart the
   * shop itself owns, addressed by id rather than by clicking a theme's
   * buttons. It wants a nonce, which the cart itself hands out, and for a
   * product sold in sizes it wants the size named.
   *
   * Newer versions hand back a Cart-Token instead of relying on a cookie, and
   * a token nobody replays is a cart nobody can find again - so it is kept in
   * sessionStorage, which survives the navigation to the cart page.
   */
  /**
   * Add through the product page's own form, not through the Store API.
   *
   * The API cart and the cart the classic checkout reads are the same cart
   * only while they share a session, and asking the API for one detaches them
   * - the item is there, the checkout says the basket is empty, and it bounces
   * you back. Posting the form the shop rendered is what a person does, and it
   * lands in the session the checkout actually reads.
   */
  wooAdd: async function () {
    const wait = ms => new Promise(r => setTimeout(r, ms));
    try {
      const form = document.querySelector('form.cart, form[enctype][class*="cart"], form[action*="add-to-cart"]');
      if (!form) return { ok: false, detail: 'no add-to-cart form on the page' };

      // A product sold in sizes needs one chosen before it can be added; the
      // shop's own script fills in the variation id once it is.
      const chosen = [];
      for (const sel of form.querySelectorAll('select[name^="attribute"]')) {
        const options = [...sel.options].filter(o => o.value);
        if (!options.length) continue;
        // Whatever the shop already has selected is its own recommendation.
        // Failing that, take the middling option rather than the first one -
        // the first is usually the smallest, and nobody asked for the smallest.
        const opt = options.find(o => o.value === sel.value)
          || options.find(o => /medium|regular|standard|one.?size|default/i.test(o.textContent))
          || options[Math.floor((options.length - 1) / 2)];
        sel.value = opt.value;
        sel.dispatchEvent(new Event('change', { bubbles: true }));
        chosen.push(opt.textContent.trim());
        await wait(700);
      }

      const fd = new FormData(form);
      const btn = form.querySelector('[name="add-to-cart"]');
      if (btn && !fd.get('add-to-cart')) fd.set('add-to-cart', btn.value);
      if (!fd.get('quantity')) fd.set('quantity', '1');

      const res = await fetch(form.getAttribute('action') || location.href, {
        method: 'POST', credentials: 'same-origin', body: fd, redirect: 'follow',
      });
      if (!res.ok) return { ok: false, detail: `the store returned ${res.status}` };
      const html = await res.text();
      const err = /<ul[^>]*class="[^"]*woocommerce-error[\s\S]{0,400}?<\/ul>/i.exec(html);
      if (err) return { ok: false, detail: err[0].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 90) };
      return { ok: true, added: chosen.join(', ') || 'item' };
    } catch (err) {
      return { ok: false, detail: err.message.slice(0, 80) };
    }
  },

  wooClear: async function () {
    // Every line on the cart page carries its own remove link, signed by the
    // shop. Following them is the only removal it will accept.
    const wait = ms => new Promise(r => setTimeout(r, ms));
    try {
      for (let round = 0; round < 6; round++) {
        const html = await (await fetch('/cart/', { credentials: 'same-origin' })).text();
        const links = [...html.matchAll(/href="([^"]*remove_item=[^"]*)"/g)]
          .map(m => m[1].replace(/&amp;/g, '&'));
        if (!links.length) return { empty: true, rounds: round };
        for (const href of links) {
          await fetch(href, { credentials: 'same-origin', redirect: 'follow' }).catch(() => {});
          await wait(150);
        }
      }
      return { empty: false, detail: 'the cart would not empty' };
    } catch (err) {
      return { empty: false, detail: err.message.slice(0, 80) };
    }
  },

  wooCart: async function () {
    try {
      const j = await (await fetch('/wp-json/wc/store/v1/cart', { credentials: 'same-origin' })).json();
      const minor = 10 ** (j.totals?.currency_minor_unit ?? 2);
      const sym = j.totals?.currency_symbol ?? '$';
      const total = j.totals ? Number(j.totals.total_price) / minor : null;
      // WordPress encodes anything past ASCII, and this runs in a page, so the
      // page's own parser is the shortest way back to the characters.
      const plain = h => { const el = document.createElement('textarea'); el.innerHTML = String(h ?? ''); return el.value; };
      return {
        lines: (j.items || []).map(i => ({
          name: plain(i.name) + (i.variation?.length ? ` — ${i.variation.map(v => plain(v.value)).join(', ')}` : ''),
          qty: i.quantity, total: (Number(i.totals?.line_total ?? 0) / minor).toFixed(2),
        })),
        total, totalText: total === null ? null : `Total: ${sym}${total.toFixed(2)}`,
        blocked: false, notice: null, url: location.href,
      };
    } catch (err) {
      return { lines: [], blocked: false, notice: null, error: err.message.slice(0, 80), url: location.href };
    }
  },

  opencartAdd: async function (productId) {
    try {
      const res = await fetch('index.php?route=checkout/cart/add', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'x-requested-with': 'XMLHttpRequest' },
        body: `product_id=${encodeURIComponent(productId)}&quantity=1`,
      });
      if (!res.ok) return { ok: false, detail: `the store returned ${res.status}` };
      const j = await res.json().catch(() => ({}));
      const err = j.error && Object.values(j.error).find(Boolean);
      if (err) return { ok: false, detail: String(err).replace(/<[^>]+>/g, '').slice(0, 80) };
      return { ok: true, added: 'item' };
    } catch (err) {
      return { ok: false, detail: err.message.slice(0, 80) };
    }
  },

  opencartClear: async function () {
    // Clicking each remove control in turn races the reload it triggers, and
    // what survives the race is a second line on the cart the run did not
    // choose. Read the keys, post the removals, read again.
    const url = 'index.php?route=checkout/cart';
    const keysOf = html => {
      // Templates emit the key as cart.remove('54'), and the quote is often an
      // entity by the time it reaches us. Options make the key composite.
      const t = html.replace(/&#0?39;|&apos;/g, "'").replace(/&quot;/g, '"');
      const keys = new Set();
      for (const m of t.matchAll(/cart\.remove\(\s*['"]?([\w:.-]+)['"]?\s*\)/g)) keys.add(m[1]);
      for (const m of t.matchAll(/name="quantity\[([^\]]+)\]"/g)) keys.add(m[1]);
      return [...keys];
    };
    const read = async () => {
      for (let n = 0; n < 3; n++) {
        try { return await (await fetch(url, { credentials: 'same-origin' })).text(); }
        catch { await new Promise(r => setTimeout(r, 500)); }
      }
      return null;
    };

    try {
      for (let round = 0; round < 6; round++) {
        const html = await read();
        if (html === null) return { empty: false, detail: 'the cart page would not load' };
        const keys = keysOf(html);
        if (!keys.length) return { empty: true, rounds: round };
        for (const key of keys) {
          await fetch('index.php?route=checkout/cart/remove', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
              'x-requested-with': 'XMLHttpRequest' },
            body: `key=${encodeURIComponent(key)}`,
          }).catch(() => {});
        }
      }
      return { empty: false, detail: 'the cart would not empty' };
    } catch (err) {
      return { empty: false, detail: String(err && err.message || err).slice(0, 90) };
    }
  },

  addToCart: function () {
    const btn = document.querySelector(
      '#button-cart, button[name="add"], #add-to-cart, form[action*="/cart/add"] button[type="submit"]');
    if (!btn) return { ok: false, detail: 'no add-to-cart control' };
    const text = (btn.innerText || btn.value || '').trim();
    if (/\bpay\b|\bplace order\b|\bbuy now\b|\bconfirm\b/i.test(text)) return { ok: false, detail: `refused to click "${text}"` };
    btn.click();
    return { ok: true, clicked: text };
  },

  shopifyCart: async function () {
    try {
      const j = await (await fetch('/cart.js', { credentials: 'same-origin' })).json();
      return {
        lines: (j.items || []).map(i => ({
          name: i.product_title + (i.variant_title && i.variant_title !== 'Default Title' ? ` — ${i.variant_title}` : ''),
          qty: i.quantity, total: (i.line_price / 100).toFixed(2),
        })),
        totalText: `Total: $${(j.total_price / 100).toFixed(2)}`,
        total: j.total_price / 100,
        blocked: false, notice: null, url: location.href,
      };
    } catch (err) {
      return { lines: [], blocked: false, notice: null, error: err.message.slice(0, 80), url: location.href };
    }
  },

  readCart: function () {
    const rows = [...document.querySelectorAll('tbody tr, .cart-item, [data-cart-item], li.cart__item')]
      .map(tr => {
        const cells = [...tr.querySelectorAll('td')].map(x => x.innerText.replace(/\s+/g, ' ').trim());
        if (cells.length >= 4) return { name: cells[1] || cells[0], qty: Number(cells[3]) || 1, total: cells[cells.length - 1] };
        const t = tr.innerText.replace(/\s+/g, ' ').trim();
        return t ? { name: t.slice(0, 70), qty: 1, total: (t.match(/\$[\d,.]+/g) || []).pop() || '' } : null;
      }).filter(Boolean);
    const body = document.body.innerText;
    const notice = (/Products marked with \*\*\*[^\n]*/i.exec(body) || [])[0] || null;
    const empty = /your (shopping )?(cart|bag) is (currently )?empty/i.test(body);
    return {
      lines: empty ? [] : rows.slice(0, 6), notice,
      blocked: !!notice || rows.some(r => /\*\*\*/.test(r.name)),
      url: location.href,
    };
  },

  checkoutGate: function () {
    return {
      bouncedToCart: /\/cart(\?|$|#)|route=checkout\/cart/.test(location.href),
      hasGuest: !!document.querySelector('input[name="account"][value="guest"]'),
      url: location.href,
    };
  },

  chooseGuest: function () {
    const radio = document.querySelector('input[name="account"][value="guest"]');
    if (radio) { radio.checked = true; radio.dispatchEvent(new Event('change', { bubbles: true })); }
    const btn = document.querySelector('#button-account');
    if (btn) btn.click();
    return { ok: !!radio };
  },

  countryOffered: async function (country) {
    // The list is populated by the checkout's own script; reading it on the
    // first tick sees an empty select and wrongly concludes the merchant ships
    // nowhere.
    const find = () => [...document.querySelectorAll('select')].find(s =>
      /country/i.test(`${s.name} ${s.id} ${s.getAttribute('autocomplete') || ''}`)
      && !/shipping/i.test(`${s.name} ${s.id}`) || null)
      || [...document.querySelectorAll('select')].find(s =>
        /country/i.test(`${s.name} ${s.id} ${s.getAttribute('autocomplete') || ''}`));
    const deadline = Date.now() + 9000;
    let sel = null;
    while (Date.now() < deadline) {
      sel = find();
      if (sel && sel.options.length > 10) break;
      await new Promise(r => setTimeout(r, 250));
    }
    if (!sel) return { offered: false, count: 0, reason: 'no country field on this page' };
    const opts = [...sel.options].map(o => o.textContent.trim());
    return { offered: opts.includes(country), count: opts.length };
  },

  /**
   * Fill what the browser's own autofill would fill. Card fields are excluded
   * before any matching runs, so no lucky label can reach one.
   */
  fillCheckout: async function (profile) {
    const CARD = /card|cardnumber|cc-?(number|exp|csc|cvc)|cvv|cvc|security.?code|expir/i;
    const BY_AUTOCOMPLETE = {
      email: 'email', username: 'email',
      'given-name': 'first_name', 'family-name': 'last_name', name: 'full_name',
      'address-line1': 'address_1', 'street-address': 'address_1', 'address-line2': 'address_2',
      'address-level2': 'city', 'address-level1': 'zone', 'postal-code': 'postcode',
      country: 'country', 'country-name': 'country', tel: 'telephone', 'tel-national': 'telephone',
    };
    const BY_LABEL = [
      ['email', /e.?mail/i], ['first_name', /first.?name|given|fname/i],
      ['last_name', /last.?name|surname|family|lname/i],
      ['address_1', /address.?(line)?.?1|street|addr1|^address$/i],
      ['address_2', /address.?(line)?.?2|addr2|apartment|suite|unit/i],
      ['city', /city|town|locality/i], ['zone', /state|province|region|county|\bzone\b|zone_?id/i],
      ['postcode', /zip|postal|postcode/i], ['country', /country|country_?id/i],
      ['telephone', /phone|mobile|^tel$|telephone/i],
    ];
    const data = { ...profile, full_name: [profile.first_name, profile.last_name].filter(Boolean).join(' ') };

    const keyOf = el => {
      const ac = (el.getAttribute('autocomplete') || '').toLowerCase().split(/\s+/).pop();
      if (BY_AUTOCOMPLETE[ac]) return BY_AUTOCOMPLETE[ac];
      const blob = [el.name, el.id, el.placeholder, el.getAttribute('aria-label')].filter(Boolean).join(' ');
      return BY_LABEL.find(([, re]) => re.test(blob))?.[0] ?? null;
    };
    const setVal = (el, v) => {
      el.focus?.();
      el.value = v;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.blur?.();
    };
    const pickOption = (sel, want) => {
      const w = String(want).toLowerCase();
      const opt = [...sel.options].find(o => o.textContent.trim().toLowerCase() === w)
        || [...sel.options].find(o => o.textContent.trim().toLowerCase().includes(w));
      if (!opt) return null;
      sel.value = opt.value;
      sel.dispatchEvent(new Event('change', { bubbles: true }));
      return opt.textContent.trim();
    };

    // select2 and its cousins hide the element they enhance and draw their own.
    // The hidden one is still the field the form reads, and still the one that
    // fires the events the checkout listens for.
    const onScreen = el => el.offsetParent !== null
      || (el.tagName === 'SELECT' && el.options.length > 1);
    const visible = () => [...document.querySelectorAll('input, select, textarea')]
      .filter(el => onScreen(el) && !el.disabled && !el.readOnly)
      .filter(el => !['hidden', 'submit', 'button', 'password', 'file', 'checkbox', 'radio'].includes((el.type || '').toLowerCase()))
      .filter(el => !CARD.test(`${el.name} ${el.id} ${el.placeholder || ''} ${el.getAttribute('autocomplete') || ''}`));

    const filled = [];

    // Country first, because the region field is rebuilt from it - sometimes
    // into a different list, sometimes into a plain text box because the
    // country has no regions. Reading it before that happens picks a state in
    // the wrong country, so wait for it to actually change.
    const zoneShape = () => {
      const z = visible().find(el => keyOf(el) === 'zone');
      if (!z) return 'none';
      return z.tagName === 'SELECT' ? `select:${[...z.options].map(o => o.value).join(',')}` : 'text';
    };
    const countryEl = visible().find(el => keyOf(el) === 'country');
    if (countryEl && data.country) {
      const before = zoneShape();
      if (countryEl.tagName === 'SELECT') { if (pickOption(countryEl, data.country)) filled.push('country'); }
      else { setVal(countryEl, data.country); filled.push('country'); }
      for (let n = 0; n < 24 && zoneShape() === before; n++) await new Promise(r => setTimeout(r, 300));
      await new Promise(r => setTimeout(r, 500));
    }

    for (const el of visible()) {
      const key = keyOf(el);
      if (!key || key === 'country' || key === 'zone') continue;
      const v = data[key];
      if (!v || filled.includes(key)) continue;
      if (el.tagName === 'SELECT') { if (pickOption(el, v)) filled.push(key); continue; }
      setVal(el, String(v));
      filled.push(key);
    }

    // Region last: it only exists once the country has settled.
    let zones = [], zone = null;
    const zoneEl = visible().find(el => keyOf(el) === 'zone');
    if (zoneEl && data.zone) {
      if (zoneEl.tagName === 'SELECT') {
        zones = [...zoneEl.options].map(o => o.textContent.trim());
        zone = pickOption(zoneEl, data.zone);
        if (zone) filled.push('region');
      } else { setVal(zoneEl, data.zone); zone = data.zone; filled.push('region'); }
    }

    return { filled, zones, zone };
  },

  checkoutReady: function () {
    const wanted = /address|city|postcode|zip|country|first.?name|last.?name|e.?mail/i;
    const fields = [...document.querySelectorAll('input, select')]
      .filter(el => wanted.test(`${el.id} ${el.name} ${el.getAttribute('autocomplete') || ''}`));
    return { ready: fields.length >= 4, fields: fields.length, url: location.href };
  },

  needsFill: function () {
    const wanted = /address|city|postcode|zip|firstname|first_name|lastname|last_name|email/i;
    return [...document.querySelectorAll('input')]
      .filter(el => el.offsetParent !== null && !el.disabled && !el.readOnly)
      .filter(el => wanted.test(`${el.id} ${el.name} ${el.getAttribute('autocomplete') || ''}`))
      .some(el => !el.value);
  },

  /**
   * Shops pre-tick "email me with news and offers". A checkout we filled and
   * handed over is one the user is about to pay from, so leaving it ticked
   * signs them up by our omission. We never tick boxes; we do untick this one.
   */
  /**
   * Shopify recognises a returning phone or email and throws a Shop Pay
   * "confirm it's you" modal with a one-time code. It is not a failure and it
   * is not ours to answer — but a checkout sitting behind a modal nobody
   * mentioned looks like the run half-worked.
   */
  verificationWall: function () {
    const otp = document.querySelector('input[autocomplete="one-time-code"], input[name*="verification" i]');
    if (otp) return { wall: 'code', where: 'Shop Pay' };
    const t = document.body.innerText || '';
    if (/confirm it'?s you|enter the code we sent|verification code/i.test(t)) return { wall: 'code', where: 'the shop' };
    return { wall: null };
  },

  clearMarketing: function () {
    const MARKETING = /accepts?[-_]?marketing|buyer_accepts|newsletter|opt[-_]?in|subscribe|email_?me/i;
    let cleared = 0;
    for (const el of document.querySelectorAll('input[type="checkbox"]')) {
      const id = `${el.name || ''} ${el.id || ''} ${el.getAttribute('aria-label') || ''}`;
      const label = el.labels?.[0]?.textContent || '';
      if (!MARKETING.test(id) && !/news and offers|newsletter|marketing|subscribe/i.test(label)) continue;
      if (el.checked) { el.click(); cleared++; }
    }
    return { cleared };
  },

  advance: function () {
    const COMMIT = /\bconfirm order\b|\bplace order\b|\bpay now\b|\bcomplete (order|purchase)\b|\bbuy now\b|\bconfirm (and )?pay\b|\bsubmit order\b/i;
    // Accepting a shop's terms is a consent, and consents are not ours to give.
    // The whole promise is that the last click is yours; ticking the agreement
    // box on your behalf quietly breaks it. Report it instead.
    const agree = document.querySelector('input[name="agree"]');
    if (agree && !agree.checked) return { needsConsent: true };

    for (const sel of ['#button-guest', '#button-shipping-method', '#button-payment-method',
      '#button-shipping-address', '#button-payment-address', '#button-account']) {
      const el = document.querySelector(sel);
      if (!el || el.offsetParent === null) continue;
      const text = (el.innerText || el.value || '').trim();
      if (COMMIT.test(text)) return { moved: false, refused: text };
      if (/loading|please wait/i.test(text)) continue;
      el.click();
      return { moved: true, clicked: text || sel };
    }

    const generic = [...document.querySelectorAll('button, input[type=submit]')]
      .filter(el => el.offsetParent !== null)
      .map(el => ({ el, text: (el.innerText || el.value || '').trim() }))
      // A button that says "Loading…" is a button mid-flight, not a step.
      .find(({ text }) => /continue to (shipping|payment|delivery)|^continue$|next step/i.test(text)
        && !COMMIT.test(text) && !/loading|please wait/i.test(text));
    if (generic) { generic.el.click(); return { moved: true, clicked: generic.text }; }

    const commit = [...document.querySelectorAll('button, input[type=submit]')]
      .map(el => (el.innerText || el.value || '').trim()).find(t => COMMIT.test(t));
    return { moved: false, refused: commit || null };
  },

  revealFilled: function () {
    const opened = [];
    for (const id of ['collapse-payment-address', 'collapse-shipping-address', 'collapse-shipping-method']) {
      const el = document.getElementById(id);
      if (!el) continue;
      el.classList.add('in'); el.style.height = 'auto'; el.style.display = 'block';
      opened.push(id);
    }
    return { opened };
  },

  readiness: function (intendedTitle) {
    const COMMIT = /\bconfirm order\b|\bplace order\b|\bpay now\b|\bcomplete (order|purchase)\b|\bconfirm (and )?pay\b/i;
    // querySelector with a list returns the first match in document order, not
    // the first selector that matches - so ask in priority order.
    const table = document.querySelector('#collapse-checkout-confirm table')
      || document.querySelector('.table-responsive table')
      || document.querySelector('table');
    const lines = table ? [...table.querySelectorAll('tbody tr')].map(tr => {
      const td = [...tr.querySelectorAll('td')].map(x => x.innerText.replace(/\s+/g, ' ').trim());
      return td.length >= 4 ? { name: td[0], qty: Number(td[2]) || 1 } : null;
    }).filter(Boolean) : [];

    const text = document.body.innerText;
    const commitControl = [...document.querySelectorAll('button, input[type=submit]')]
      .map(el => (el.innerText || el.value || '').trim()).find(t => COMMIT.test(t)) || null;
    // Shops bill in their own money. "Total: £71.50" was not matched at all, so
    // a $22.50 notebook looked like it was still under a $25 ceiling while the
    // till said seventy-one pounds.
    // Either a currency marker or real decimals — otherwise "Total 1 item"
    // reads as a total of one, which is how the panel came to show "1" as the
    // price of a hot sauce set.
    const totalRow =
      (text.match(/Total[:\s]*(?:[$£€₪¥]|USD|GBP|EUR|ILS|NIS)\s*[\d,]+(?:\.\d{2})?/i) || [])[0]
      || (text.match(/Total[:\s]*[\d,]+\.\d{2}/i) || [])[0]
      || null;
    const currency = totalRow ? (totalRow.match(/[$£€₪¥]|USD|GBP|EUR|ILS|NIS/i) || ['$'])[0] : null;
    const money = s => { const m = /\$?\s*([\d,]+\.\d{2})/.exec(s || ''); return m ? Number(m[1].replace(/,/g, '')) : null; };

    const missing = [];
    if (!commitControl) missing.push('no commit control on the page');
    if (!totalRow) missing.push('no readable total');
    if (lines.length > 1) missing.push(`cart shows ${lines.length} lines, expected 1`);
    else if (lines.length === 1 && intendedTitle &&
      !lines[0].name.toLowerCase().includes(String(intendedTitle).toLowerCase().slice(0, 18)))
      missing.push(`cart holds “${lines[0].name}”, expected “${intendedTitle}”`);

    // A red asterisk marking a required field is not an error. Only text that
    // actually reads like a complaint counts.
    const err = [...document.querySelectorAll('.text-danger, .alert-danger, [role="alert"], [aria-invalid="true"]')]
      .filter(n => n.offsetParent !== null)
      .map(n => n.innerText.trim())
      .find(t => t.length > 5 && /required|invalid|error|must be|enter a|please|problem|cannot|unable|not available/i.test(t))
      || null;
    if (err) missing.push(`blocking error: ${err.slice(0, 60)}`);

    return {
      ready: missing.length === 0, missing, lines, commitControl,
      totalText: totalRow, total: money(totalRow), currency,
      addressOnPage: [...document.querySelectorAll('input')]
        .filter(i => /address|city|postcode|zip|first|last/i.test(`${i.id} ${i.name}`))
        .map(i => `${(i.id || i.name).replace(/^.*\[|\]$/g, '')}=${i.value}`).filter(v => !/=$/.test(v)),
      url: location.href,
    };
  },
};
