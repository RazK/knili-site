/**
 * The panel.
 *
 * Injected on demand and docked beside the page, in a shadow root so the
 * merchant's stylesheet and this one cannot reach each other. It is destroyed
 * and rebuilt on every navigation, which is fine: the background holds the run,
 * and the panel asks for the whole state the moment it reappears.
 */
(() => {
  // Reloading the extension orphans the copy of this script already running in
  // the page: its globals survive, its chrome.* does not. Re-injecting then hit
  // the guard below and re-showed a panel wired to a dead port — visible,
  // clickable, and connected to nothing. Check the context before trusting it.
  const contextAlive = () => { try { return !!chrome.runtime?.id; } catch { return false; } };
  if (window.__kniliPanel) {
    if (contextAlive()) { window.__kniliPanel.show(); return; }
    try { window.__kniliPanel.destroy(); } catch {}
    delete window.__kniliPanel;
  }

  // Two homes for the same panel. In Chrome's side panel it is simply the page,
  // and the browser gives it the column — the page beside it is resized by
  // Chrome rather than by us, which is the whole reason to be here: docking by
  // setting margin-right on someone else's <html> covers content on any site
  // that lays out against the viewport instead of the document.
  const SIDE_PANEL = location.protocol === 'chrome-extension:';

  const WIDTH = 404;
  const host = document.createElement('div');
  host.id = 'knili-host';
  // Every one of these is !important: a merchant stylesheet that sets, say,
  // `div{position:absolute;width:0}` wins over a plain inline style and leaves
  // the panel a zero-width sliver. Allbirds does exactly that.
  const lock = (k, v) => host.style.setProperty(k, v, 'important');
  if (SIDE_PANEL) {
    lock('position', 'static'); lock('width', '100%'); lock('height', '100vh');
    lock('display', 'block'); lock('margin', '0'); lock('padding', '0');
  } else {
    lock('position', 'fixed'); lock('top', '0'); lock('right', '0');
    lock('width', WIDTH + 'px'); lock('height', '100vh');
    lock('z-index', '2147483647'); lock('display', 'block');
    lock('visibility', 'visible'); lock('opacity', '1');
    lock('margin', '0'); lock('padding', '0'); lock('transform', 'none');
  }
  const root = host.attachShadow({ mode: 'open' });
  // Chrome already draws a title bar with the extension's name, icon and a
  // close button. Ours underneath it is the same thing twice, so in the side
  // panel we keep only what Chrome does not show: the run's status and setup.
  if (SIDE_PANEL) host.dataset.chrome = 'side-panel';
  (SIDE_PANEL ? document.body : document.documentElement).appendChild(host);
  const dock = on => {
    if (SIDE_PANEL) return;
    document.documentElement.style.setProperty('margin-right', on ? WIDTH + 'px' : '', 'important');
  };
  dock(true);

  window.__kniliPanel = {
    show() { lock('display', 'block'); dock(true); },
    hide() { lock('display', 'none'); dock(false); },
    toggle() { host.style.display === 'none' ? this.show() : this.hide(); },
    destroy() { dock(false); host.remove(); },
  };

  const FONT = f => chrome.runtime.getURL('fonts/' + f);

  // @font-face is ignored inside a shadow root — the rule has to live in the
  // document that owns it. The faces are still ours and still local; only the
  // declaration goes outside.
  if (!document.getElementById('knili-faces')) {
    const faces = document.createElement('style');
    faces.id = 'knili-faces';
    faces.textContent = `
      @font-face{font-family:KniliDisplay;src:url(${FONT('Oswald-600.woff2')}) format("woff2");
        font-weight:400 700;font-display:swap}
      @font-face{font-family:KniliMono;src:url(${FONT('DMMono-400.woff2')}) format("woff2");
        font-weight:400;font-display:swap}
      @font-face{font-family:KniliMono;src:url(${FONT('DMMono-500.woff2')}) format("woff2");
        font-weight:500 700;font-display:swap}`;
    document.documentElement.appendChild(faces);
  }
  root.innerHTML = `
<style>
  :host{all:initial}
  *{box-sizing:border-box;margin:0;padding:0}

  /* KIOSK — saturated cobalt, condensed caps, acid yellow, flat blocks, zero
     radius. Drawn to the brand board, not approximated from memory. The faces
     ship with the extension: a merchant's CSP would eat a remote webfont, and
     half the shops on the web would render this in Times. */

  .p{--g:#1B2CF0;--ink2:#0A1140;--ink:#FFFFFF;--body:#D3D8FF;--dim:#9AA6F5;
     --rule:#4152F5;--acid:#E8FF3A;--acid-ink:#5C6606;--acid-body:#3A4210;
     --paper:#FFFFFF;--bad:#D6003C;
     height:100vh;display:flex;flex-direction:column;background:var(--g);color:var(--body);
     font:400 13px/1.45 KniliDisplay,Impact,Haettenschweiler,sans-serif;letter-spacing:.01em}

  /* header — a solid navy band, status as an acid stamp */
  header{display:flex;align-items:center;gap:11px;padding:13px 16px;background:var(--ink2)}
  .brand{display:none;height:19px;width:auto}
  .brand.paper{display:block}
  :host([data-chrome="side-panel"]) .brand{display:none}
  .tag{font:600 10px/1 KniliDisplay,Impact,sans-serif;letter-spacing:.18em;text-transform:uppercase;
       background:var(--acid);color:var(--ink2);padding:4px 9px}
  .tag[data-idle="1"]{background:transparent;color:var(--dim);box-shadow:inset 0 0 0 1px var(--rule)}
  .icons{margin-left:auto;display:flex;gap:12px}
  .icon{background:none;border:0;cursor:pointer;color:var(--dim);
        font:400 10px/1 KniliMono,ui-monospace,Menlo,monospace;letter-spacing:.06em}
  .icon:hover{color:var(--acid)}

  .scroll{flex:1;overflow-y:auto;padding:0 0 22px}

  /* section heads — acid, wide caps, generous air */
  h3{font:600 11px/1 KniliDisplay,Impact,sans-serif;letter-spacing:.24em;text-transform:uppercase;
     color:var(--acid);margin:26px 16px 11px}
  .scroll > div:first-child > h3:first-child,
  #main > div:first-child > h3:first-child{margin-top:16px}

  /* composer — one full-width band, field and button shoulder to shoulder */
  .composer{display:grid;grid-template-columns:1fr auto;margin:16px 16px 0}
  #storeList{margin:0 16px;width:calc(100% - 32px)}
  textarea{background:var(--ink2);border:0;padding:13px 14px;color:var(--ink);resize:vertical;
     font:400 13.5px/1.35 KniliDisplay,Impact,sans-serif;text-transform:uppercase;letter-spacing:.02em;
     min-height:76px}
  textarea::placeholder{color:var(--dim)}
  textarea:focus{outline:2px solid var(--acid);outline-offset:-2px}
  .go{background:var(--acid);color:var(--ink2);border:0;padding:13px 18px;cursor:pointer;
     font:600 15px/1 KniliDisplay,Impact,sans-serif;letter-spacing:.06em;text-transform:uppercase;
     white-space:nowrap;display:grid;place-items:center}
  .go:hover{filter:brightness(1.05)}
  .go[data-busy="1"]{background:var(--rule);color:var(--dim)}
  .hint{font:400 11px/1.5 KniliMono,ui-monospace,Menlo,monospace;color:var(--dim);margin:10px 16px 0;
     text-transform:none;letter-spacing:0}

  /* starters — flat navy blocks in caps */
  .starters{display:flex;flex-wrap:wrap;gap:4px;margin:10px 16px 0}
  .starters button{background:var(--ink2);border:0;padding:6px 11px;cursor:pointer;color:var(--ink);
     font:500 11.5px/1 KniliDisplay,Impact,sans-serif;letter-spacing:.1em;text-transform:uppercase}
  .starters button:hover{background:var(--acid);color:var(--ink2)}

  /* envelope chips */
  .chips{display:flex;flex-wrap:wrap;gap:4px;margin:0 16px}
  .chip{background:var(--ink2);padding:6px 11px;font:500 11.5px/1 KniliDisplay,Impact,sans-serif;
     letter-spacing:.1em;text-transform:uppercase;color:var(--ink)}
  .chip b{display:block;font-weight:500}
  .chip i{display:none}
  .chip.late{background:var(--acid);color:var(--ink2);font-weight:600}
  .chip.pref{background:transparent;color:var(--dim);box-shadow:inset 0 0 0 1px var(--rule)}

  /* receipts — mono rows, a dash for a bullet, the live one in acid */
  .now{display:flex;align-items:center;gap:10px;margin:0 16px;background:var(--ink2);
     padding:11px 13px}
  .now span{flex:1;font:400 12px/1.4 KniliMono,ui-monospace,Menlo,monospace;color:var(--acid);
     overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .more{background:transparent;border:0;cursor:pointer;color:var(--dim);
     font:500 10px/1 KniliDisplay,Impact,sans-serif;letter-spacing:.14em;text-transform:uppercase}
  .more:hover{color:var(--acid)}
  .steps{margin:8px 16px 0;max-height:220px;overflow-y:auto}
  .steps div{font:400 12px/1.4 KniliMono,ui-monospace,Menlo,monospace;color:var(--body);padding:5px 0 5px 18px;
     position:relative;text-transform:none;letter-spacing:0;border-bottom:1px solid var(--rule)}
  .steps div:before{content:"";position:absolute;left:0;top:11px;width:7px;height:2px;
     background:var(--dim)}
  .steps div.run{color:var(--acid)}
  .steps div.run:before{background:var(--acid);width:11px}
  .steps div.warn{color:var(--dim)}

  /* the survivor — an acid block, the name enormous */
  .card{background:var(--acid);color:var(--ink2);padding:17px 16px;margin:0 16px}
  .pic{display:block;width:100%;height:150px;object-fit:contain;background:var(--paper);
     margin-bottom:12px}
  .m{font:400 10px/1 KniliMono,ui-monospace,Menlo,monospace;letter-spacing:.1em;text-transform:uppercase;
     color:var(--acid-ink)}
  .t{font:600 30px/.98 KniliDisplay,Impact,sans-serif;letter-spacing:.01em;text-transform:uppercase;
     color:var(--ink2);margin:9px 0 8px}
  .t a{color:inherit;text-decoration:none}
  .why{font:400 12px/1.5 KniliMono,ui-monospace,Menlo,monospace;color:var(--acid-body);text-transform:none;
     letter-spacing:0}
  .ev{display:grid;grid-template-columns:auto 1fr auto;gap:4px 12px;margin-top:14px;
     padding-top:12px;border-top:2px solid var(--ink2);font:400 12px/1.4 KniliMono,ui-monospace,Menlo,monospace}
  .ev dt{font-size:10px;color:var(--acid-ink);text-transform:uppercase;letter-spacing:.08em}
  .ev dd{color:var(--ink2);font-weight:500}
  .ev a{font-size:9px;color:var(--acid-ink);text-decoration:none}

  /* the rejects and the rounds */
  .rej,.att{margin:0 16px}
  .rej > div,.att > div{background:transparent;box-shadow:inset 0 0 0 1px var(--rule);
     padding:9px 12px;margin-bottom:2px}
  .rej b,.att b{font:500 12.5px/1.2 KniliDisplay,Impact,sans-serif;letter-spacing:.04em;text-transform:uppercase;
     color:var(--dim);display:block}
  .rej span,.att em{font:400 10.5px/1.35 KniliMono,ui-monospace,Menlo,monospace;color:var(--dim);font-style:normal;
     text-transform:none;letter-spacing:0;display:block;margin-top:3px}
  .pill{font:500 10px/1 KniliDisplay,Impact,sans-serif;letter-spacing:.12em;text-transform:uppercase;
     padding:4px 7px;background:var(--ink2);color:var(--dim);white-space:nowrap}
  .pill.ready{background:var(--acid);color:var(--ink2)}
  .pill.bad{background:var(--bad);color:var(--paper)}
  .pill.warn{background:var(--rule);color:var(--ink)}
  .att > div{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center}

  /* the verdict — a navy sign, the headline in acid caps */
  .out{background:var(--ink2);padding:20px 16px;margin:0 16px}
  .out.bad{background:var(--paper)}
  .out h4{font:600 30px/.98 KniliDisplay,Impact,sans-serif;letter-spacing:.01em;text-transform:uppercase;
     color:var(--acid)}
  .out.bad h4{color:var(--bad)}
  .out p{font:400 12px/1.55 KniliMono,ui-monospace,Menlo,monospace;margin-top:10px;color:var(--body);
     text-transform:none;letter-spacing:0}
  .out.bad p{color:#3A3F5E}
  .opic{display:block;width:100%;height:170px;object-fit:contain;background:var(--paper);
     margin:14px 0 0}
  .buy{margin-top:14px}
  .buy-t{font:600 20px/1.05 KniliDisplay,Impact,sans-serif;letter-spacing:.01em;text-transform:uppercase;
     color:var(--ink)}
  .out.bad .buy-t{color:var(--ink2)}
  .buy-p{font:600 34px/1 KniliDisplay,Impact,sans-serif;color:var(--acid);letter-spacing:-.01em;margin-top:8px}
  .buy-p em{display:block;font:400 9.5px/1.3 KniliMono,ui-monospace,Menlo,monospace;font-style:normal;
     letter-spacing:.1em;text-transform:uppercase;color:var(--dim);margin-top:6px}
  .buy-m{margin-top:10px;display:flex;gap:4px;flex-wrap:wrap}
  .buy-m span{background:var(--g);color:var(--ink);padding:5px 9px;
     font:500 10.5px/1 KniliDisplay,Impact,sans-serif;letter-spacing:.1em;text-transform:uppercase}
  .kv{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:16px;
     font:400 9.5px/1 KniliMono,ui-monospace,Menlo,monospace;text-transform:uppercase;letter-spacing:.1em;
     color:var(--dim)}
  .kv b{display:block;font:600 24px/1 KniliDisplay,Impact,sans-serif;color:var(--acid);margin-top:5px;
     letter-spacing:0}
  .out.bad .kv b{color:var(--ink2)}
  .go-link{display:inline-block;margin-top:12px;color:var(--acid);
     font:400 11px/1.4 KniliMono,ui-monospace,Menlo,monospace;text-decoration:none;word-break:break-all}
  .foot{margin-top:14px;padding-top:12px;border-top:1px solid var(--rule);
     font:400 10.5px/1.5 KniliMono,ui-monospace,Menlo,monospace;color:var(--dim);text-transform:none;letter-spacing:0}

  /* answers and ways out */
  .answer-row{display:flex;gap:4px;margin-top:12px}
  .sugg{display:flex;flex-direction:column;gap:2px;margin-top:14px}
  .sugg button{text-align:left;padding:11px 13px;border:0;background:var(--g);color:var(--ink);
     cursor:pointer;font:500 12.5px/1.25 KniliDisplay,Impact,sans-serif;letter-spacing:.06em;
     text-transform:uppercase}
  .sugg button:hover{background:var(--acid);color:var(--ink2)}
  .sugg button em{display:block;font:400 10.5px/1.35 KniliMono,ui-monospace,Menlo,monospace;font-style:normal;
     letter-spacing:0;text-transform:none;color:var(--dim);margin-top:4px}
  .sugg button:hover em{color:var(--acid-ink)}

  /* setup */
  .who{display:flex;align-items:center;gap:12px;margin:0 16px 14px}
  .avatar{width:44px;height:44px;background:var(--acid);color:var(--ink2);display:grid;
     place-items:center;font:600 18px/1 KniliDisplay,Impact,sans-serif;letter-spacing:.04em}
  .whoT b{display:block;font:600 15px/1.1 KniliDisplay,Impact,sans-serif;letter-spacing:.04em;
     text-transform:uppercase;color:var(--ink)}
  .whoT span{display:block;font:400 11px/1.4 KniliMono,ui-monospace,Menlo,monospace;
     color:var(--dim);margin-top:3px;text-transform:none;letter-spacing:0}
  label{display:block;font:400 9.5px/1 KniliMono,ui-monospace,Menlo,monospace;letter-spacing:.12em;
     text-transform:uppercase;color:var(--dim);margin:0 0 5px}
  input{width:100%;background:var(--ink2);border:0;padding:10px 12px;color:var(--ink);
     font:400 13px/1.3 KniliDisplay,Impact,sans-serif;letter-spacing:.02em}
  input:focus{outline:2px solid var(--acid);outline-offset:-2px}
  .grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:0 16px 8px}
  .grid.one{grid-template-columns:1fr}
  .save{margin:8px 16px 0;width:calc(100% - 32px);background:var(--acid);color:var(--ink2);
     border:0;padding:12px;cursor:pointer;font:600 13px/1 KniliDisplay,Impact,sans-serif;
     letter-spacing:.08em;text-transform:uppercase}

  /* a default scrollbar on a cobalt panel is a white seam down the edge */
  .scroll,.steps{scrollbar-width:thin;scrollbar-color:var(--rule) transparent}
  .scroll::-webkit-scrollbar,.steps::-webkit-scrollbar{width:9px}
  .scroll::-webkit-scrollbar-track,.steps::-webkit-scrollbar-track{background:transparent}
  .scroll::-webkit-scrollbar-thumb,.steps::-webkit-scrollbar-thumb{background:var(--rule)}
  .scroll::-webkit-scrollbar-thumb:hover,.steps::-webkit-scrollbar-thumb:hover{background:var(--acid)}
  .hide{display:none!important}
</style>
<div class="p">
  <header>
    <img class="brand paper" alt="Knili" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAbgAAACoCAYAAACSa/ucAAAACXBIWXMAAAAAAAAAAQCEeRdzAAAQAElEQVR4nO2debgcVZnGRUARRIZNUFRgRIIbhIRAgAiIO2ELOCJkRFklCsqiBllEEEVIIqA8owM88ADKLiYIA8+oMDiisgwIgsgOCblr7tL33r69Vfc357vVN6l0urqqur6vz+m+7/s8P3L/oes9p6vrrTp1znfeRERvAgAAADoN6wYAAAAADawbAAAAADSwbgAAAADQwLoBAAAAQAPrBgAAAAANrBsAAAAANLBuAAAAANDAugEAAABAA+sGAAAAAA2sGwAAAAA0sG4AAAAA0MC6AQAAAEAD6wYAAAAADawbAAAAADSwbgAAAADQwLoBAAAAQAPrBgAAAAANrBsAAAAgzhmGO4S4yrCJA21KjHUDAAAAxFlKcuoxbO5AmxJj3QAAAHQgWxjmGhYZfm34TZVbDecY5hjeonj820hOrxj+RdHrRw2nGW4I9BPDT47zDe9r9rNtnwQAANBJbGY41/AyRetxw1cMb1bw0Q4Bt7/hHkMx4vj9hv807Jz0GLZPBiB3opxt+LYC5xn2Efb7dsMsw56CvN+B7yHIFsLtq2W6YT0H2gnW8DHD05Rc9xp2EPbicsDxk+tPDIWEPlYZTk5yLNsnBEgP39V0k5747mknYc9zFHzeKewxDfwDflChjUF9z4F2gjUcbBhp+I011quGPQT9uBpwG5E/ZJtGl8c9nu2TAqQ/Wf5IeiqR/x5B2ve+Cl5vVfDZLD9TaF9QtznQRrCGT1C6cJvUcpK7mXQx4Hgo9nYhTz+Mc0zbJwZIx1WkqwuVfHdywJ2o0LagnjNs5UA7gc+O5AeTlP5seJuALxcD7hJBT6yjoo5p++QAzfPvhgrp6XeG9ZW8d2rA7WUYVmjbpPgpYW8H2gnW8KuG31hzWijgy7WA43fuSd+5Rek1irjZs31ygObgCQaDpKcVpDtpoxMDbkvyn640tcByG8Ha8DuzfMNvrDnxO/WtU3pzLeBuFfQT1DmNjmv7BAHJ4RmIT5CeyobPK7ehEwPuLoU2BXW95faBdbmy0ReWUsen9OZSwH2AZN5R1tNThreGHdv2CQKScwPpakkL2tBpAXeBQnuC4vVSb7fYPrAuPHz/VKMvLaV+ldKfSwE3X9BLrTzDbmHHtn2SgGScSrriGZma1RUm6aSAO5T82aZa4qHo6ZbaBsL5V/LXZWmJR2nSTDZxKeCWCHqpp2PDjm37JAHx4cXWY7XfrKAGDLu0qC2dEnA8pbtLoS2T4klEoT9eYBV+/6Z5Y8OhslkKfy4FnNTSgDCdHnZs2ycJiMc7Df9c52uVE19I57ewPZ0QcHx3/bBCO4L6aYvbBOLDswIRcPG4Q9BLPSHg2hztE+Q/WtyeTgi4Xyi0ISgOz41b3CYQH37vMx767aXXi4Z3pPDnUsDdKOilnk4NO7btkwREc06dL1RSj1HrJzC0e8B9VcF/UDzsmbiwLGgpPKqyIuwLFNCDlG4dqksBp30NOzjs2LZPEtCYT1F0pe004gkMoTOQFGnngOOF1hkF/5PiZRpHtqgtIB3/HfIdSujSlN5cCjguZaZVlIILK7wr7Ni2TxAQzvbkr9TX1Fctta1dA44X376g4D2oH7egHUCGU0K+w7TiMJiT0ptLAbcp6f1uft3o2LZPEFAf3gZF8+6QdZ3F9rVjwPF3skzBd1D3k87eYEAH3uX6lbrfZDr9QcCbSwHHnCXoJ6jPNjqu7RME1OdHdb9KOfEC1TQztNLSjgF3kYLnoF4n/6nd9rkHknFcne8yjXIkU2/UtYDbhOQXxkcuhrd9coB14TJZmkWUR8l+wd52C7h5pDslnOsZflrRP9BFsrrQd4Q8uRZwDF93RoU8cd3XbaKOafvEAGvDC601Fw6zTnOgne0UcNNId0NZVsOCscB5eF9GieHrHwl6cjHgGL5ZTFuw4iWKWZTC9okB1sBrnrQXDt/hQDuZdgk4Hlb5i4LXoJYp+Aathxf+X0PNibeROU/Yj6sBx/B7s2aXWHBd1mlxj2X7pABr0N4F+nlyZ6PMdgm4Zi9YcfUPw7YKvoE9eBeAJDMGHzF8UsGHywHH8HZcN5O/LCaOeDkAb5iaaM2u7ZMB+Ei/qK5V1rCfA+2cpB0C7msKHoPi72R/Yc/ADTgMTjLcQ/7kIa54X67C71u57N4thsMMGyp5cD3gJpltuIr8J7ORQD8x/Yb/MXyP/LqviT/f9okA/ErxQ6Sr7zrQziCuBxyvQdLav2pSZwr6Be7CoyY7kr/7ALM9tWYGc7sE3CQ8xPseWtNPDC/gTlPNBQFnGa419yTpaqkD7azF5YDjmVkvKfgL6iYhrwCE0W4Bp4J1A1Mc7c1LX6UGZWws4mrA8SLrexS8BfU0+QuEbX8HoLNBwBECzibfIF3xWP/nHGhnPVwNOO0F9vyifJaATwCiQMARAs4W/I5Hc6sN1oUOtDMMFwOOF9hrLuZmnZDSIwBxQcARAs4GPGSouXkpi+tYbuBAW8NwLeA+aOhV8BTU1Sn8AZAUBBwh4GzAkz40tdKwgwPtbIRLAcfrah5V8BPUnwmbl9aDb8I2qvZNLW8jt2/SXAcBR37A6VUv97w3VWhcgYJah1SqKH3+d9Y5dWTFa0cOV/IuiUsBd72Cl6B4Lc+Hm/TWSXBVmBnkD9PyXmdcVYdvLF4m/+m5Fl4/xpvx3kn+u9Evkf+kjdCLBwKO/IDjk+du8ksGiVLseunebtpnWR/NFaOXPrEsQxcso4q8X2aw4N0zSvRb4c9dmif6r0K50kO6794WkwMnVQxcCbjTFHwExQt8j27ClzQcCpsKEjdk+OmYb7iuJf8imU/XnRM1DHlZzSKyXzB8Et5GaZMUfVnLRkK+XAy4DQX7ic+tyDVy/J/jBTtiLRXz3TQ4fBh10x6GvYSYTj3D5iZwQMmzoaBQy59v41flNTfnnthD6i1k/wcfBxcCbn+Sq2wepkUJPWnBFTP6BflMxPG4/Nj55JeH0xJPCOJznicH2Xyq44stP4lK9a3UPo0uBtxJgv3ET/kzo47J/3mr4RnBzggoR5nRnxS7aHfqoX2E2JN6xg/3vPFH49YwS6AKLScqPzqUy0p/7tPmB/nccDYn+7lribeFt30hjYvtgOOJPhobVQb1IPm/Ldt9zRwl3LZDQ47Dd9VnG94QPl6U/mQ4JMSTNlys4VXBtvxGyJeLAfdNQU+s2VHHnPzjZOEDr1Z++J9ejzejLBdws6mvdACNjl6Vdrijrnj8cKgonZ0V/sUXu8cLabeJaKS9yP6FNC42A46HNe5TOH5QXCm9qdp5SvybcPvqhQkvfXlM+DhJxYUTWl3YgAPuRcE23Cnky8WAk1z7yxfpyGve5B88hvys4MFXq1Qcqoz0fdvrplliT3Hd5olwVf5UT2uAqVSpjJfiV7mOqQq/jynIfuZacuWdRBxsBtylCscOiofObD1NhKEdcFyYWvPmLYk4bFo5moGAi4+1gJs8SRVUobHBpYUu2lVwmHIWrRw8qkjD3Z6G49eyhVJv1bukyuKfuJYQcNHH5aE6lXMmoIti+Gg1mgGnfcPQjPhVAF/PWtG3CLj4WA04ro/3qqCB1SoVuso9NMOTe4Lbi/oLcymXuVvlYuWVKxxE4u/4ugse+S/hVGIOAdf4mDxVv1/huEHdHeHBFtIBN7f6uYuFP1dardhFAwEXH6sBx5wlaCCgLA2PXFzspplyw5SVmTTkLczLx1CFCwaWV+ZKwkMuFXp8pJAfnPgTAafQ/kYBxxehxxWOGRRfBLZr4MEm0gHHQ4AnCH+mls4h3b5FwMXHesBtTkqzywp9z5S6aBfBYcqZ1NV3Qol6qSwbF5WJjcD68vIPh8tz3nB24vENAafQ/kYBd6PC8YLiuUkHNji+bSQDjk/eK0l/vzxJLSC9vkXAxcd6wDHnCppYrVK5tzIw/oUSDy+KLRfIzSt72b8qLBcwgVyu5Iryw5Sa664QcPWPdbrCsWr1rZBju4L0E5ziq2QV8bKfj5NO3yLg4uNEwPEwS4+gkdXKrlhWXEkfEXoPN5v6ivvT6MiVKmvLnhvJF97Qe9rSEAJu3ePwRU14TeM6ur3OcV1DOuDaUbzofEuS71sEXHycCDjmQkEjq1Uce93rLc8UnGwynfqzp028NBP3Wi5zD4qmGz++jZXUJvEh4NY+xnsNyxWOExRvXqpx0ZQGAefr5yTftwi4+DgTcO8xrBI0U7U0SiO9Fxe7aIbwcoE3hFOjwpXAyq9mJRdmT1RJqXRlCypDqoSACwYclyz7vcIxguJ3UO3S5wg4X1wr7wCS7VsEXHycCTjmCkEzq5Vf/mRpJU0TWy6wKj+XxlfdJVzksTKR7q+PS5Y0qfAmcMWXR6TLgK1Wu1xsGe2AW6Lw+bX6Otnrv6Qg4NaIb3wk+xYBFx+nAu79BvHBv2KpuzyUOabczZNEREJuBg0Wzi5p1AgZ98rFguAwpfmgYkXvnRACzv9s3lZF+8WpVEHcVoGAWyO+MH6a5PoWARcfpwKOuVzQUFU5ymSvKHbRbkLDlHtQT25+iTzpYUqivw3ncq/JTjThD8IQpU7AcejwfmFDCp8d1P+RX0Hedh8mAQG3tu4iub5FwMXHuYDbhRSeOPKjz3t9hT3LPeaaLLFcoC9/eLmYfUg8OPJeeaKwoKTGvYpWraipHnC/I/2duTk8p5P9/kuKCwHHN3fcfzxDO7ixqY0aljzfaxrJ9C0CLj7OBRxznaCpCXnFgcrIqoUl3idOZrnAx2gkc4X4ICUXXM55ZdGAfz3nVe8YxEfRpnrAtUI8/Gm775rBVsDxtjk3kb9byf6GD5C/V9y7qrzbsBv52+983/AI6dcKnRRfbCX6FgEXHycD7qOk8BQ3Nvjb/Er6kNB7uN2pL7vAM/eCgqkxMZNSfKLJH4fyYxMFEeXLdSHgdPUzst9vzdLqgONdt48zbJHQJ++OzecGX5y1g+7BhN7CQMDFx8mAY24SNDah/OjKcqb3GE9mssme1F2YV/JIdhPUagSVSPBxq6vgZZQKLiPg9PS/5M7mpc3QqoDjoT+u6iLRV7xr+HOKXrks7I4CPhFw8XE24HjnVOHXUeOUGb5cZLdvDsmB8YNpvPsu8WFK8wSXXUWia761dvVGwOmom/yhNdt9loZWBBxXCpkl7JuHMzXXM4btTJ4EBFx8nA045g5BcxPKD/291EXTRHb75mHKwfzZHgnv8z1U9CYq6UqJvxXh6tCTQsDJi8+mw8h+f6VFO+C4ost7lbxzgDyk5PtiIX8IuHg4HXD8FCe6oNqr9JQHcseWZHb7nkXd2WOK5L0mOnZvHgnLWa8slnH8Xm+4ID03c0IIOHnxDD/2aru/0qIZcF3kv6fX9L8D+RNWpLVMwBsCLj5OBxxzj6DBCWW77i1KTDbhYcr+3BFUGHxQdFIIz2N+eawgFJoVfqngvTwyLvycOSEEnI6eoeSTJVxDM+COblEbjlfw/g/DBil9IeDi43zAfYqEZ0cUci97vd5sPW80CAAADI5JREFUL+2auG7z//cX96XM4OK8pENONn+DbwlV6FnT5Bcz4xprfxBwerqZ7PdZGrQCrpU7mHMQPSbsfyX5SxXS+ELAxcf5gGPuEzRprvlZyvQsKslMNtmdeseklwsQvTRWyPbKTTThYV7J13qTQsDp6ptkv9+aRSPg+ALT6uHbbwq3gWd9ph1eRcDFpy0C7nOCJicyI9/zBE82qUgsF+gpHFHyKo+ILhdYVShVyy04vTccAk5XvBZ0H7Lfd82gEXAPWWjHTiR7c8g/6LTfKQIuPm0RcG82PCxolEqlleWh4a+knmzC7+EGs3Mpu+J20eUC5hdVyRQ9sfdmA8WyRm3oqR5wXCNSe/+3Z6k99n+rRSPgzrLQDh6m/JNwOw5K6QkBF5+2CDhmnqBR4qVhw7mfFrpoV4Fhyuk0kF3oyVW48/dxezqTE8qkCj09Wixmqn8LaqoHHJeU43VN2hUw6u0c7jrSAcfTgD9sqS0/F27LvJR+EHDxaZuA45I6ondS+ezz5f7cHIECzLOoK3t0gbxXxC50/EGe4ESTJ0eLmeHq34Ka6gF3S/WzL1H47FqdTvb7MAnSAcezD99hqS1nC7fl8JR+EHDxaZuAY+YLmqVKeYCGM+eUulPu9s3DnAPZIynf+4DonfxIqTyWk9vqJiP0OUFN9YCbfLJa3/AHhc8Pit8DtdP6OOmAk1g/1ixfEm4LAi5aUzLgNiK/qKqYxjL3l7pSronj5QJ9pb0pM7SoILnz2hu5UsXfaEzkqUtjGA0Bt+bztze8qnCMoLhO4lZkrw+TIB1wP7XYliOE24KAi9aUDDjmWEHDlB9b4WV6v+yln2yyO/VmFpRo1JOcTcnJJvIejmerFOTrdSHg1j7GZ0m48k4d3UZ2+i8p0gH3LYttOVK4LQi4aE3ZgHsb+ePxQsrR8PCVhS6anvo9XG/+yHKp8BchXxXqNx36erYoMJOyMlHbqC8nfu1FwK17nPMVjlOrM+oc1zWkA+4ki21BwMUDAUfpA445Vcwyr4kbecrrol1SFmDem3q82TRavFyscj9/0LjIA2GFK9MWn89kpRd7I+DqH+suhWMFxYuFXe976YCTqMLfLAi4eCDgSCbgNjW8IOe6uzKQOyn1bt/dtButGl3o8eVHajBwuFjmVEqdclmiwrjwTuHk/kU2SCsDbhsSPD9D9Hdyu16ldMAdbLEtCLh4IOBIJuCYr4vZNmk01nNfwTzFpRym3IO6x+YXqfiS2Hu417LF8sCkyXTiSSbSY5QIuPDj7UcKu9LX6KYGx7eNdMAdYrEtCLh4IOBILuD47nWFlPNC8QWvr7Sf10OzUzzB7UX9+c/S+MidYkFSjTWRGZClinjhLwRc42NK1zGsp1MjPNgCARcuBFy0pnzAMefIWc9RpueKYhftlnKYclca8i4oyTwrVbj0ePmF0bzIu7PuQll6b1YEXPRxf6lw3KBGyM3vAQEXLgRctBBwhq1JqhagebTJDTzOk01SFmCeQd2rTinSiMykfK7+NVKSmWjy50xhfHDiT7HnuHYqBGwr4DYz/E3h2EHx/nGu1atEwIULARctBFyVi6Tce6WVNDR0IvHCb17X1gxd9BHqzc2lYlZux/v+wsS8FUo3wFihp0aLJeF6lHPI3kUnKbYCjtmDqPoV6umXMb20CgRcuBBw0ULAVdnWcJlhiWFxs1T43zItGV/+8KJBOnPxMJ3bFEN09uLxsSWL8yueaNpLLS+NFRb1T/xdSftZP5byZLjcsIPwd6mJzYBjjiP9vY++kcCPNgi4cCHgooWAAyABtgOO+YWCh6D4KdGVepUIuHAh4KKFgAMgAS4E3MYGqVI3YeL941yoV4mACxcCLloIOAAS4ELAMbsY+hS8BPWrJnxJg4ALFwIuWgg4ABLgSsAxXyT9TVIXNOlNCgRcuBBw0ULAAZAAlwKOuUzBT1A8YXZWCn9pQcCFCwEXLQQcAAlwLeA2JP1NUnn9ncRFohkQcOFCwEULAQdAAlwLOGZHEiw3F6IbUnpsFgRcuBBw0ULAAZAAFwOOOYiENrVtIBvv4xBw4ULARQsBF4Np5P/QFhouNVxCfgHcuYZ3ttCH62xCftmtEw0XVvuK/z2++oVu6IDHtLgacMwFCt6C4nqVewp5jQsCLlwIuGgh4EJYz/AF8t9vZBqY7TFcS34ZJVs/HNtsZ/g++XuXhZWH5vrMT5F/k2DrfY4ELgccs0zBX1D8HW4u6DcKBFy4EHDRQsDVgZ/Y7k9omiv1/8CwgaIvFzmGkheq5qK+n3HAezO4HnBcck7yolVPrdw/DgEXLgRctBBwNexvWJnC/N3k9g7JkvwwRT/xk95pDrQhKa4HHHMA6W+S+jVhz2Eg4MKFgIsWAi4A754sUR3iAcNGCv5c4hKBfmK5VNg3Du0QcMwZCj6D4vdxkT9SARBw4ULARQsBV2V7kp1qfa2wP5c4WbCf+EnuIAfaFJd2CTjmFgWvQT1N+qMVCLhwIeCihYCrcrNgAyY1T9ijC+xgGJDsJKPnyd/Q03bb4tBOAceTQbQ3SdVeH4eACxcCLloIOPKntktsd12rR6nzJp1cIdpDa3SmA22LQzsFHMM/pEazgCV0kqJ/BFy4EHDRQsAZrhE0X6sDBH3ahtf89ch2z2o9YXiLA22Mot0CjjlJwXNQHKAzlLwj4MKFgIvWlA84/pL/KWi+VpcK+XSBQ4X7Jih+F7ebA22Moh0DjrlawXdQfIPyDgXfCLhwIeCiNeUDbmfSGZ6c1ANCPl3gB8J9U6svO9DGKNo14N5ueETBe1DXKfhGwIULARetKR9wBwoar6fHqTNKVDE3CvdNrb7jQBujaNeAYz5oWKXgP6ivCntGwIULARetKR9wnxI0Xk8ccO3wbikOvxTum1otdKCNUbRzwDFceaai0IZJ8fq4mYJ+EXDhQsBFa8oH3H6Cxuupk57grhPum1p924E2RtHuAccsUWhDUE+S3LIPBFy4EHDRmvIB937S3WbkPiGfLnC+cN/U6gsOtDGKTgg4vuF6QKEdQV0v5BUBFy4EXLSmfMBtaviHoPlaXSTk0wXmCvdNUDnDhx1oYxSdEHDMToYuhbYEdYqATwRcuBBw0ZryAcdcJWi+tiH7CPq0zZakt3P0Xw1vdqCNUXRKwDEHk+7oBb+PS7uNFAIuXAi4aCHgyP8Rhu1jlka/F/ToCpeJ9tAaHedA2+LQSQHHXKTQnqC4VFia93EIuHAh4KKFgKsiXc2EZ6odKOzRBd5teEOwn1g8Eadddl/otIBbn/wtnjR1dQp/CLhwIeCihYCrsjX5O1JL6Qphfy7xRcF+4n3L9nOgTXHptIBj3kX+hUBTxzfpDQEXLgRctBBwAfYkmRfvS6nziizXcp5AP7G+4kBbktCJAcd8kvxd6bU0bJjehC8EXLgQcNFCwNUw27A8hfnbyS+LZOtH1ErSLBvIG050oA1J6dSAY85UaFtQPBSd9LeBgAsXAi5aCLg68BTq3yY0zXe/F1J7zASUhIcrX0vYV8+QX0HGtvdm6OSAY25XaF9Q1yT0g4ALFwIuWgi4BhxleJAa76fVR/7u3c0Mv3QK2xguJv/HEla42jM8aziLZE44W3R6wG1l+LtCG4M6IYEfBFy4EHDRQsDF4EOG+YbvGr5XhYdz+Mfynhb6cB0efuIJI6dU++j86r8nG+YYNnbAY1o6PeAYfhc9otDOSfH7uLj7xyHgwoWAixYCDoAEaNQuXepAu2pZoNDOoPjCum0MH8cIH3dejGNqITn7mPX5lH54fWK3oJ97U/qZRHLZSq9hcwFPZwl6YkUWALF9AQBTE15OcrQw+zrQrlrWI7/SiXRbGQ6tYw07xPDxPuFjb2exT98r3Ja0o0dck/QQQT9zhPppX0FP3D6J3Vx2Fv7utow6pu0LAAAA2GY9BzwABawbAAAAADSwbgAAAADQwLoBAAAAQAPrBgAAAAANrBsAAAAANLBuAAAAANDAugEAAABAA+sGAAAAAA2sGwAAAAA0sG4AAAAA0MC6AQAAAEAD6wYAAAAADawbAAAAADSwbgAAAADQwLoBAAAAQAPrBgAAAAANrBsAAAAANLBuAAAAANDAugEAAABAA+sGAAAAAA2sGwAAAAA0sG4AAAAA0MC6AQAAAEAD6wYAAAAADawbAAAAADSwbgAAAADQwLoBAAAAQAPrBgAAAAANrBsAAAAANLBuAAAAANDAugEAAABAA+sGAAAAAA2sGwAAAAA0sG4AAAAA0MC6AQAAAEAD6wYAAAAADawbAAAAADSwbgAAAADQ4P8BkYmr8iO50eMAAAAASUVORK5CYII="><span class="tag" id="tag">idle</span>
    <span class="icons">
      <button class="icon" id="settingsBtn" title="Your details and shops">profile</button>
      <button class="icon" id="closeBtn" title="Close">close</button>
    </span>
  </header>
  <div class="scroll">
    <div id="setup" class="hide">
      <h3>Profile</h3>
      <div class="who"><div class="avatar" id="avatar">—</div>
        <div class="whoT"><b id="whoName">Nobody yet</b><span id="whoWhere">tell it where things go</span></div></div>
      <div class="grid">
        <div><label>First name</label><input id="f_first_name"></div>
        <div><label>Last name</label><input id="f_last_name"></div>
      </div>
      <div class="grid"><div><label>Email</label><input id="f_email"></div>
        <div><label>Phone</label><input id="f_telephone"></div></div>
      <div class="grid one"><div><label>Address</label><input id="f_address_1"></div></div>
      <div class="grid"><div><label>City</label><input id="f_city"></div>
        <div><label>Postcode</label><input id="f_postcode"></div></div>
      <div class="grid"><div><label>Country</label><input id="f_country"></div>
        <div><label>Region</label><input id="f_zone"></div></div>
      <button class="save" id="saveProfile">Save details</button>
      <p class="hint">Stored in this browser only. There is no card field, and no server to send it to.</p>

      <h3>Shops on file</h3>
      <textarea id="storeList" placeholder="https://allbirds.com"></textarea>
      <button class="save" id="saveStores">Save stores</button>
      <p class="hint">One URL per line. Any Shopify store works. Whatever store you are on is always included.</p>
    </div>

    <div id="main">
      <div class="composer">
        <textarea id="q" placeholder="what you want, what you&#39;ll pay, where it goes"></textarea>
        <button class="go" id="go">Fine, go</button>
      </div>
      <div class="starters" id="starters"></div>
      <p class="hint" id="hint">Vague in, vague out. Give it a number and a street.</p>

      <div id="briefBox" class="hide"><h3>Held to</h3><div class="chips" id="chips"></div></div>
      <div id="stepBox" class="hide"><h3>Receipts</h3>
        <div class="now" id="now"><span id="nowText">Working…</span><button class="more" id="moreBtn">show</button></div>
        <div class="steps hide" id="steps"></div></div>
      <div id="decBox" class="hide"><h3>The survivor</h3><div class="card">
        <img id="dpic" class="pic hide" alt="">
        <div class="m" id="dm"></div><div class="t" id="dt"></div>
        <div class="why" id="dw"></div><dl class="ev" id="ev"></dl>
      </div></div>
      <div id="rejBox" class="hide"><h3>The rejects</h3><div id="rej"></div></div>
      <div id="attBox" class="hide"><h3>The rounds</h3><div id="att"></div></div>
      <div id="outBox" class="hide"><h3>Verdict</h3><div class="out" id="out">
        <h4 id="oh"></h4>
        <img id="opic" class="opic hide" alt="">
        <div id="obuy" class="buy hide">
          <div class="buy-t" id="obt"></div>
          <div class="buy-p" id="obp"></div>
          <div class="buy-m" id="obm"></div>
        </div>
        <p id="op"></p><div class="kv" id="okv"></div><div class="foot" id="os"></div>
      </div></div>
    </div>
  </div>
</div>`;

  const $ = id => root.getElementById(id);

  /**
   * The order of the column, in one place. What you are buying is always at the
   * top — during the run, not only at the end — and the box you typed in drops
   * below it, because you have already typed in it.
   */
  const COMPOSER = ['q', 'starters', 'go', 'hint'];
  function layout({ answerFirst }) {
    const main = $('main');
    const order = answerFirst
      ? ['outBox', 'decBox', ...COMPOSER, 'briefBox', 'stepBox', 'rejBox', 'attBox']
      : [...COMPOSER, 'outBox', 'decBox', 'briefBox', 'stepBox', 'rejBox', 'attBox'];
    for (const id of order) { const el = $(id); if (el) main.appendChild(el); }
  }
  const show = id => $(id).classList.remove('hide');
  const hide = id => $(id).classList.add('hide');
  const money = n => n == null ? '—' : '$' + Number(n).toFixed(2);
  const PROFILE_FIELDS = ['first_name', 'last_name', 'email', 'telephone', 'address_1', 'city', 'postcode', 'country', 'zone'];

  const NAME = { price: 'Price', inStock: 'Stock', availability: 'Availability',
    brand: 'Brand', productType: 'Type', variantCount: 'Variants' };
  const showVal = (a, v) => v == null ? 'unknown'
    : a === 'price' ? money(v) : a === 'inStock' ? (v ? 'in stock' : 'sold out') : String(v);

  // MV3 tears the service worker down after ~30s idle, which kills the port.
  // Posting into a dead port throws "Attempting to use a disconnected port
  // object" and the panel sits on "Working…" forever. So: reconnect on demand,
  // and never hold a port across a wait.
  let port = null;
  let onPortMessage = () => {};
  function connect() {
    port = chrome.runtime.connect({ name: 'knili' });
    port.onMessage.addListener(msg => onPortMessage(msg));
    port.onDisconnect.addListener(() => { port = null; });
    return port;
  }
  function send(msg) {
    try { (port || connect()).postMessage(msg); }
    catch { port = null; connect().postMessage(msg); }
  }
  connect();

  $('moreBtn').onclick = () => {
    const open = !$('steps').classList.contains('hide');
    $('steps').classList.toggle('hide', open);
    $('moreBtn').textContent = open ? 'show' : 'hide';
  };

  $('closeBtn').onclick = () => window.__kniliPanel.hide();
  $('settingsBtn').onclick = () => {
    const open = $('setup').classList.contains('hide');
    $('setup').classList.toggle('hide', !open);
    $('main').classList.toggle('hide', open);
    $('settingsBtn').textContent = open ? 'back' : 'profile';
  };
  $('saveProfile').onclick = () => {
    const profile = {};
    for (const f of PROFILE_FIELDS) profile[f] = $('f_' + f).value.trim();
    send({ t: 'saveProfile', profile });
    renderWho(profile);
    $('saveProfile').textContent = 'Saved';
    setTimeout(() => ($('saveProfile').textContent = 'Save details'), 1400);
  };
  $('saveStores').onclick = () => {
    const stores = $('storeList').value.split('\n').map(l => l.trim()).filter(Boolean)
      .map(u => { try { const o = new URL(u.startsWith('http') ? u : 'https://' + u); return { name: o.hostname.replace(/^www\./, ''), origin: o.origin }; } catch { return null; } })
      .filter(Boolean);
    send({ t: 'saveStores', stores });
    $('saveStores').textContent = `Saved ${stores.length}`;
    setTimeout(() => ($('saveStores').textContent = 'Save stores'), 1400);
  };

  let running = false;

  /** Three errands worth pressing without thinking about it. They are written
   *  against your saved address when there is one, so a click is a whole
   *  request rather than a half-finished sentence. */
  /** The profile, as a face and a line — not a form you have to read. */
  function renderWho(p) {
    const name = [p?.first_name, p?.last_name].filter(Boolean).join(' ');
    const where = [p?.city, p?.country].filter(Boolean).join(', ');
    $('avatar').textContent = name
      ? name.split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase()
      : '—';
    $('whoName').textContent = name || 'Nobody yet';
    $('whoWhere').textContent = where || 'tell it where things go';
  }

  function renderStarters(profile) {
    const box = $('starters');
    box.textContent = '';
    const where = [profile?.city, profile?.country].filter(Boolean).join(', ');
    const to = where ? `, shipped to ${where}` : '';
    const ideas = [
      ['65W GaN charger', `65w gan usb-c charger under $70${to}`],
      ['Merino socks', `merino wool socks under $40${to}`],
      ['Coffee beans', `250g single origin coffee beans under $30${to}`],
    ];
    for (const [label, text] of ideas) {
      const b = document.createElement('button');
      b.textContent = label;
      b.title = text;
      // Load it, do not launch it: a suggestion is a starting point you edit —
      // the budget, the destination, the wording — not a command.
      b.onclick = () => { $('q').value = text; $('q').focus(); };
      box.appendChild(b);
    }
  }
  renderStarters(null);

  $('go').onclick = () => {
    // While a run is in flight this same button stops it. One control, and it
    // always does the thing its label says.
    if (running) { send({ t: 'cancel' }); $('go').textContent = 'Stopping…'; $('go').disabled = true; return; }
    const text = $('q').value.trim();
    if (!text) {
      // Pressing a button and having nothing happen is the panel ignoring you.
      $('hint').textContent = 'Tell it what to buy first — a thing, a budget, and where it ships.';
      $('hint').classList.remove('hide');
      $('q').focus();
      return;
    }
    running = true;
    // A run starting means you are done editing your profile.
    $('setup').classList.add('hide');
    $('main').classList.remove('hide');
    $('settingsBtn').textContent = 'profile';
    layout({ answerFirst: false });
    $('hint').classList.remove('hide');
    $('starters').classList.add('hide');
    $('go').disabled = false; $('go').textContent = 'Stop';
    ['briefBox', 'stepBox'].forEach(show);
    hide('outBox');
    $('steps').textContent = ''; $('chips').textContent = '';
    send({ t: 'start', text });
  };
  $('q').addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') $('go').click();
  });

  function addStep(e) {
    // One live line is the progress. The log is evidence, and evidence is
    // something you ask for.
    const now = $('nowText');
    if (now && e.level !== 'warn') now.textContent = e.text;

    const d = document.createElement('div');
    d.className = e.level || 'run';
    d.textContent = e.text;
    $('steps').appendChild(d);
    $('steps').scrollTop = $('steps').scrollHeight;
  }

  function renderBrief(brief) {
    show('briefBox');
    const box = $('chips'); box.textContent = '';
    for (const c of brief.constraints) {
      const el = document.createElement('div');
      el.className = 'chip' + (c.kind === 'preference' ? ' pref' : c.when === 'checkout' ? ' late' : '');
      el.textContent = c.kind === 'hard' ? c.label : `prefer ${c.dir} ${c.attr}`;
      const em = document.createElement('em');
      em.textContent = c.when === 'checkout' ? `${c.because} — checked at the checkout` : c.because;
      el.appendChild(em);
      box.appendChild(el);
    }
  }

  function renderDecision(d) {
    if (d.chosen) {
      show('decBox');
      layout({ answerFirst: true });
      root.querySelector('.scroll').scrollTop = 0;
      // A product is a thing you look at. A card that names it without showing
      // it is asking you to trust a string.
      const shot = $('dpic');
      if (d.chosen.image) { shot.src = d.chosen.image; shot.alt = d.chosen.title; shot.classList.remove('hide'); }
      else { shot.removeAttribute('src'); shot.classList.add('hide'); }
      $('dm').textContent = d.chosen.merchant;
      $('dt').textContent = '';
      const a = document.createElement('a');
      a.href = d.chosen.url; a.target = '_blank'; a.rel = 'noreferrer'; a.textContent = d.chosen.title;
      $('dt').appendChild(a);
      $('dw').textContent = d.rationale || '';
      const dl = $('ev'); dl.textContent = '';
      for (const e of d.chosen.evidence) {
        if (e.value == null) continue;
        const dt = document.createElement('dt'); dt.textContent = NAME[e.attr] || e.attr;
        const dd = document.createElement('dd'); dd.textContent = showVal(e.attr, e.value);
        const src = document.createElement('a');
        src.href = e.sourceUrl; src.target = '_blank'; src.rel = 'noreferrer'; src.textContent = 'source ↗';
        src.title = `${e.raw} — read ${new Date(e.fetchedAt).toLocaleTimeString()}`;
        dl.append(dt, dd, src);
      }
    }
    if (d.rejected?.length) {
      show('rejBox');
      const box = $('rej'); box.textContent = '';
      for (const r of d.rejected) {
        const el = document.createElement('div'); el.className = 'rej';
        const b = document.createElement('b'); b.textContent = `${r.title} — ${money(r.price)}`;
        const s = document.createElement('span'); s.textContent = `${r.merchant} · ${r.whyNot.join('; ')}`;
        el.append(b, s); box.appendChild(el);
      }
    }
  }

  function renderAttempts(list) {
    // The pick card is live: it names the shop currently being driven, so the
    // top of the panel is never stale while the run is still moving.
    const last = list[list.length - 1];
    if (last && running) {
      const at = $('dm');
      if (at) at.textContent = `${last.merchant} · ${last.outcome.replace(/-/g, ' ')}`;
    }
    if (!list?.length) return;
    show('attBox');
    const box = $('att'); box.textContent = '';
    const cls = o => o === 'ready' ? 'ready'
      : /cart-ready/.test(o) ? 'warn'
      : /over-budget|not-ready|cart-failed|cart-empty|not-purchasable|checkout-refused/.test(o) ? 'bad' : 'warn';
    for (const a of list) {
      const el = document.createElement('div'); el.className = 'att';
      const left = document.createElement('div');
      const b = document.createElement('b'); b.textContent = a.merchant;
      const em = document.createElement('em'); em.textContent = `${a.candidate}${a.detail ? ' — ' + a.detail : ''}`;
      left.append(b, em);
      const p = document.createElement('span'); p.className = 'pill ' + cls(a.outcome); p.textContent = a.outcome;
      el.append(left, p); box.appendChild(el);
    }
  }

  const COPY = {
    ready: ['Checkout ready.', 'Item carted, address filled, shipping picked. One click left, and it is yours.'],
    cart_ready: ['Cart loaded.', 'The item is in the cart on the store. Open the checkout below and the last details are yours.'],
    needs_approval: ['Over your ceiling — your call.', 'It reached a working checkout, but the price broke the budget you set.'],
    no_result: ['Nothing meets your constraints.', 'It will not quietly relax one to give you an answer.'],
    awaiting_user: ['One thing first.', ''],
    stopped: ['Stopped.', 'Nothing was bought, and nothing is waiting on you.'],
    blocked: ['Could not finish.', ''],
    failed: ['The run failed.', ''],
  };

  function renderOutcome(status, result, work) {
    show('outBox');
    // Anything the previous outcome added to this card goes with it. A stale
    // answer box saying "Working…" under a finished run is the panel lying.
    for (const el of $('out').querySelectorAll('.answer-row, .sugg, .go-link')) el.remove();

    // The answer comes first. Everything that led to it — the envelope, the
    // log, the rejections — is evidence you consult after reading the verdict,
    // not a queue you scroll through to reach it.
    // Above the composer, not merely above the evidence. The box you typed in,
    // the starter chips and the hint added up to most of a screen, so the
    // answer still needed a scroll to reach — which is the one thing it must
    // never need.
    layout({ answerFirst: true });
    $('hint').classList.add('hide');
    $('starters').classList.add('hide');
    root.querySelector('.scroll').scrollTop = 0;
    const [h, p] = COPY[status] || COPY.blocked;
    $('out').className = 'out' + (status === 'ready' || status === 'cart_ready' ? ''
      : /needs_approval|no_result|awaiting_user/.test(status) ? ' warn' : ' bad');
    $('oh').textContent = h;

    // The thing you are buying, at the size of the thing you are buying.
    const pic = $('opic');
    if (result?.image) { pic.src = result.image; pic.alt = result.candidate || ''; pic.classList.remove('hide'); }
    else { pic.removeAttribute('src'); pic.classList.add('hide'); }

    const bought = result?.candidate || result?.merchant;
    if (bought && /ready|cart_ready|needs_approval/.test(status)) {
      show('obuy');
      $('obt').textContent = result.candidate || '';
      // Say WHICH number this is. The pay button read $29.00 while the panel
      // said $19.00 — both true, one the item and one the item plus shipping —
      // and an unlabelled big number is the panel guessing on your behalf.
      // The till's own words, symbol and all — never a dollar sign glued to a
      // number the shop wrote in pounds.
      const total = (result.totalText || '').replace(/^total[:\s]*/i, '').trim()
        || (result.total != null ? money(result.total) : null);
      const item = result.itemPrice != null ? money(result.itemPrice) : null;
      $('obp').textContent = total || item || '';
      const tag = document.createElement('em');
      tag.textContent = total ? 'total at the checkout' : item ? 'item price — shipping not counted yet' : '';
      if (total && item && result.itemPrice != null) tag.textContent += ` · item ${money(result.itemPrice)}`;
      if (tag.textContent) $('obp').appendChild(tag);
      const marks = $('obm'); marks.textContent = '';
      const chip = t => { const s2 = document.createElement('span'); s2.textContent = t; marks.appendChild(s2); };
      if (result.merchant) chip(result.merchant);
      if (result.shipsTo) chip(`ships to ${result.shipsTo}`);
      if (result.verify) chip(`${result.verify} wants a code from you`);
      if (result.total != null && result.itemPrice != null && result.total !== result.itemPrice) {
        chip(`item ${money(result.itemPrice)}`);
      }
    } else {
      hide('obuy');
    }
    // Name the thing that actually stopped it, with the count that makes it real.
    const BLOCKED = {
      'no-shipping': n => `${n} shop${n === 1 ? '' : 's'} had it. None of them ship to ${result?.wanted || 'you'}.`,
      'over-budget': n => `${n} shop${n === 1 ? '' : 's'} had it, and every one was over your ceiling at the till.`,
      challenge: n => `${n} shop${n === 1 ? '' : 's'} asked to prove you are human. That one is yours to answer.`,
      'cart-ready': n => `Carted at ${n} shop${n === 1 ? '' : 's'}, but none of them would open a checkout.`,
      'cart-failed': n => `${n} shop${n === 1 ? '' : 's'} would not put it in a basket — their carts refused the request.`,
      'over-ceiling': n => `${n} shop${n === 1 ? '' : 's'} charged more at the till than the listing promised.`,
    };
    if (status === 'blocked' && result?.dominant && BLOCKED[result.dominant]) {
      result = { ...result, message: BLOCKED[result.dominant](result.dominantShops || 1) };
    }
    $('op').textContent = result?.checkoutHost
      ? `The item is in the cart. This store runs its checkout on ${result.checkoutHost} — open it below and the last details are yours.`
      : result?.message || result?.question || (result?.reason ? `${p} (${result.reason})` : p);

    const kv = $('okv'); kv.textContent = '';
    const pairs = [];
    // A question is not a result. Nobody wants to be told that asking took a
    // second, and the same goes for any run fast enough that the number is
    // noise rather than information.
    const worthSaying = status !== 'awaiting_user';
    if (worthSaying) {
      if (result?.itemPrice != null) pairs.push(['Price', money(result.itemPrice)]);
      if (result?.total != null && result.total !== result.itemPrice) pairs.push(['Cart', money(result.total)]);
      if (work?.compared) pairs.push(['Compared', `${work.compared} listings`]);
      if (work?.stores) pairs.push(['Across', `${work.stores} stores`]);
      if (work?.seconds > 3) pairs.push(['Took', `${work.seconds}s`]);
      if (result?.merchant) pairs.push(['Store', result.merchant]);
    }
    for (const [k, v] of pairs) {
      const d = document.createElement('div');
      d.append(document.createTextNode(k));
      const b = document.createElement('b'); b.textContent = v; d.appendChild(b);
      kv.appendChild(d);
    }

    if (result?.url || result?.productUrl) {
      const a = document.createElement('a');
      a.className = 'go-link'; a.href = result.url || result.productUrl;
      a.target = '_blank'; a.rel = 'noreferrer'; a.textContent = result.url || result.productUrl;
      $('op').after(a);
    }
    // A question with nowhere to answer it is a dead end: the run stops on
    // "What is your budget?" and the only way forward is retyping the whole
    // errand. Answer it in place, and re-run with the answer appended.
    // A dead end is not an answer. Offer the smallest number of concrete ways
    // out, each carrying the real number the run just measured.
    if (status === 'blocked' && result?.dominant === 'no-shipping') {
      const box = document.createElement('div');
      box.className = 'sugg';
      const asked = $('q').value.trim();
      const b = document.createElement('button');
      b.append(document.createTextNode('Search without the delivery address'));
      const em = document.createElement('em');
      em.textContent = 'see what exists, then check shipping yourself';
      b.appendChild(em);
      b.onclick = () => {
        const text = asked.replace(/,?\s*shipp?e?d?\s+to\s+[^.;]*/i, '').trim();
        $('q').value = text;
        running = true; $('go').disabled = false; $('go').textContent = 'Stop';
        hide('outBox');
        send({ t: 'start', text });
      };
      box.appendChild(b);
      $('os').before(box);
    }

    if (status === 'no_result') {
      const box = document.createElement('div');
      box.className = 'sugg';
      const rerun = text => {
        $('q').value = text;
        running = true; $('go').disabled = false; $('go').textContent = 'Stop';
        hide('outBox');
        send({ t: 'start', text });
      };
      const offer = (label, note, text) => {
        const b = document.createElement('button');
        b.append(document.createTextNode(label));
        if (note) { const em = document.createElement('em'); em.textContent = note; b.appendChild(em); }
        b.onclick = () => rerun(text);
        box.appendChild(b);
      };
      const asked = $('q').value.trim();
      const noDest = asked.replace(/,?\s*shipp?e?d?\s+to\s+[^.;]*/i, '').trim();
      // When every shop found was undrivable, the useful move is to stop
      // restricting the search to shops that serve one country — the platforms
      // this can drive are mostly elsewhere.
      if (result?.undrivable && noDest !== asked) {
        offer('Search without the delivery address',
              'the shops it can drive are mostly abroad', noDest);
      }
      const ceiling = result?.ceiling;
      const cheapest = result?.cheapest;
      const noCap = asked.replace(/\b(?:under|below|less than|no more than|max(?:imum)?|up to)\s*\$?\s*\d+(?:\.\d{1,2})?/ig, '')
                         .replace(/\s{2,}/g, ' ').replace(/\s,/g, ',').trim();

      // Put the new ceiling where a person would put it — after the thing, before
      // the address. Appending it produced "…Jerusalem, Israel under $92".
      const withCeiling = (text, amount) => {
        const m = /(,?\s*shipp?e?d?\s+to\s+)/i.exec(text);
        if (!m) return `${text} under $${amount}`.replace(/\s{2,}/g, ' ').trim();
        const head = text.slice(0, m.index).replace(/,\s*$/, '').trim();
        return `${head} under $${amount}${text.slice(m.index)}`;
      };

      if (cheapest != null && ceiling != null) {
        const raised = Math.ceil(cheapest);
        offer(`Raise the budget to $${raised}`,
              `the cheapest that met everything else was ${money(cheapest)}`,
              withCeiling(noCap, raised));
      }
      if (ceiling != null) offer('Search with no price limit', 'see what it would have picked', noCap);
      if (result?.query) {
        const words = String(result.query).trim().split(/\s+/);
        if (words.length > 1) {
          const broader = words.slice(-2).join(' ');
          offer(`Search for just “${broader}”`, 'fewer words, more shops match', noCap.replace(result.query, broader));
        }
      }
      if (box.childElementCount) $('os').before(box);
    }

    if (status === 'awaiting_user') {
      // One answer row, replaced each time. Appending a new one per question
      // left a column of dead inputs all saying "Working…".
      const prev = $('out').querySelector('.answer-row');
      if (prev) prev.remove();
      const wrap = document.createElement('div');
      wrap.className = 'answer-row';
      wrap.style.cssText = 'display:flex;gap:6px;margin-top:10px';
      const answer = document.createElement('input');
      answer.type = 'text';
      answer.placeholder = /budget|price|spend/i.test(result?.question || '') ? 'e.g. 40' : 'your answer';
      answer.style.cssText = 'flex:1';
      const btn = document.createElement('button');
      btn.className = 'go'; btn.textContent = 'Answer';
      btn.style.cssText = 'margin-top:0;width:auto;padding:9px 14px';
      const submit = () => {
        let a = answer.value.trim();
        if (!a) return;
        // A budget answered as "40" has to reach the parser as a ceiling, not
        // as another number floating in the query next to "65w".
        if (/budget|price|spend/i.test(result?.question || '') && /^\d+(?:\.\d{1,2})?$/.test(a)) a = `under $${a}`;
        // Answering "which language?" means replacing the sentence, not adding
        // an English tail to a Hebrew one.
        const replaces = /english/i.test(result?.question || '');
        const text = replaces ? a : `${$('q').value.trim()} ${a}`.trim();
        $('q').value = text;
        btn.disabled = true; btn.textContent = 'Working…';
        running = true; $('go').disabled = false; $('go').textContent = 'Stop';
        hide('outBox');
        send({ t: 'start', text });
      };
      btn.onclick = submit;
      answer.addEventListener('keydown', e => { if (e.key === 'Enter') submit(); });
      wrap.append(answer, btn);
      $('os').before(wrap);
      setTimeout(() => answer.focus(), 0);
    }

    $('os').textContent = status === 'awaiting_user'
      ? '' : 'It stops before payment — that last click is always yours.';
    running = false;
    $('go').disabled = false; $('go').textContent = 'Fine, go';
    document.documentElement.dataset.kniliState = status;
  }

  function apply(e) {
    if (e.t === 'step') addStep(e);
    else if (e.t === 'brief') renderBrief(e.brief);
    else if (e.t === 'decision') renderDecision(e);
    else if (e.t === 'attempts') renderAttempts(e.attempts);
    else if (e.t === 'state') $('tag').textContent = e.state;
    else if (e.t === 'end') renderOutcome(e.result?.state || 'blocked', e.result, e.work);
  }

  onPortMessage = msg => {
    if (msg.t === 'hello') {
      for (const f of PROFILE_FIELDS) $('f_' + f).value = msg.profile?.[f] ?? '';
      renderStarters(msg.profile);
      renderWho(msg.profile);
      $('storeList').value = (msg.stores ?? []).map(s => s.origin).join('\n');
      if (!msg.profile?.address_1) {
        $('hint').textContent = 'Tip: add your delivery details under “profile” and it will fill the checkout too.';
      }
      const s = msg.state;
      // The run navigates the tab, and the panel comes back with it. It should
      // come back still showing what it was asked for.
      if (s?.brief?.request) $('q').value = s.brief.request;
      if (!s?.events?.length) return;
      show('briefBox'); show('stepBox');
      if (s.brief) renderBrief(s.brief);
      for (const e of s.events) if (e.t === 'step') addStep(e);
      if (s.decision) renderDecision(s.decision);
      renderAttempts(s.attempts);
      $('tag').textContent = s.status;
      if (s.result) renderOutcome(s.result.state, s.result, s.work);
      else if (s.status !== 'idle' && s.status !== 'done') { running = true; $('go').disabled = false; $('go').textContent = 'Stop'; }
      return;
    }
    apply(msg);
  };

  chrome.runtime.onMessage.addListener((m, _s, respond) => {
    if (m.t === 'toggle') { window.__kniliPanel.toggle(); respond(true); }
    return true;
  });
})();
